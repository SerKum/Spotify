package Clases;

import java.sql.Date;

public class Activa extends Playlist{

    private boolean es_compartida;

    public Activa(int id, int usuario_id, String titulo, Date fecha_creacion,boolean es_compartida) {
        super(id, usuario_id, titulo, fecha_creacion);
        this.es_compartida=es_compartida;
    }
}
