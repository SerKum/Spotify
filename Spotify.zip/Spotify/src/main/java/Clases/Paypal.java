package Clases;

public class Paypal extends FormaPago{

    private String usuario;

    public Paypal(int id, String usuario) {
        super(id);
        this.usuario = usuario;
    }

    public String getUsuario() {
        return usuario;
    }
}
