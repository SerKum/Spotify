package Clases;

public class Cancion{
    private int id;
    private String titulo;
    private int duracion;
    private int reproducciones;
    private int album_id;

    public Cancion(int id, String titulo, int duracion, int reproducciones, int album_id) {
        this.id = id;
        this.titulo = titulo;
        this.duracion = duracion;
        this.reproducciones = reproducciones;
        this.album_id = album_id;
    }

    public int getAlbum_id() {
        return album_id;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getId() {
        return id;
    }
}
