package Clases;

import java.sql.Date;

public class Premium extends Usuario{

    private Date fecha_renovacion;

    public Premium(int id, String username, String password, String email, char sexo, Date fecha_nac, String pais, String cp,Date fecha_renovacion) {
        super(id, username, password, email, sexo, fecha_nac, pais, cp);
        this.fecha_renovacion=fecha_renovacion;
    }
}
