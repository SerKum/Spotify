package Clases;

import java.sql.Date;

public class Favoritas extends Playlist {

    public Favoritas(int id, int usuario_id, String titulo, Date fecha_creacion) {
        super(id, usuario_id, titulo, fecha_creacion);
    }

}
