package Clases;


import java.util.Date;

public class Album {
    private int id;
    private int año;
    private String titulo;
    private String imagen_album;
    private boolean patrocinado;
    private Date fecha_inicio_p;
    private Date fecha_fin_p;
    private int artista_id;

    public Album(int id, int año, String titulo, String imagen_album, boolean patrocinado, Date fecha_inicio_p, Date fecha_fin_p,int artista_id) {
        this.id = id;
        this.año = año;
        this.titulo = titulo;
        this.imagen_album = imagen_album;
        this.patrocinado = patrocinado;
        this.fecha_inicio_p = fecha_inicio_p;
        this.fecha_fin_p = fecha_fin_p;
        this.artista_id = artista_id;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getAño() {
        return año;
    }

    public int getArtista_id() {
        return artista_id;
    }

    public int getId() {
        return id;
    }
}
