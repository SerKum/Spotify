package Clases;

import java.sql.Date;

public class Capitulo {
    private int id;
    private String titulo;
    private String descripcion;
    private Date fecha;
    private int podcast_id;

    public Capitulo(int id, String titulo, String descripcion, Date fecha, int podcast_id) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.podcast_id = podcast_id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public int getPodcast_id() {
        return podcast_id;
    }
}
