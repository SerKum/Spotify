package Clases;

import java.sql.Date;

public class Free extends Usuario{

    private Date fecha_revision;
    private int tiempo_publicidad;

    public Free(int id, String username, String password, String email, char sexo, Date fecha_nac, String pais, String cp,Date fecha_revision,int tiempo_publicidad) {
        super(id, username, password, email, sexo, fecha_nac, pais, cp);
        this.fecha_revision=fecha_revision;
        this.tiempo_publicidad=tiempo_publicidad;
    }

}
