package Clases;

public class Podcasts {
    private int id;
    private String titulo;
    private String descripción;
    private int año;

    public Podcasts(int id, String titulo, String descripción, int año) {
        this.id = id;
        this.titulo = titulo;
        this.descripción = descripción;
        this.año = año;
    }

    public int getId() {
        return id;
    }

    public int getAño() {
        return año;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescripción() {
        return descripción;
    }
}
