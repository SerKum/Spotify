package Clases;

import java.sql.*;
import java.util.ArrayList;
import java.sql.Date;

public abstract class Usuario{
    private int id;
    private String username;
    private String password;
    private String email;
    private char sexo;
    private Date fecha_nac;
    private String pais;
    private String cp;

    ArrayList<Usuario> seguirUsuario=new ArrayList<>();

    public Usuario(int id, String username, String password, String email, char sexo, Date fecha_nac, String pais, String cp) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.sexo = sexo;
        this.fecha_nac = fecha_nac;
        this.pais = pais;
        this.cp = cp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public Date getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(Date fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }


}
