package Clases;


import java.sql.Date;

public class Patrocinada extends Playlist{

    private Date fecha_inicio;
    private Date fecha_fin;

    public Patrocinada(int id, int usuario_id, String titulo, Date fecha_creacion,Date fecha_inicio,Date fecha_fin) {
        super(id, usuario_id, titulo, fecha_creacion);
        this.fecha_inicio=fecha_inicio;
        this.fecha_fin=fecha_fin;
    }
}
