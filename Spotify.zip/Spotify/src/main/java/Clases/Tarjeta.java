package Clases;

public class Tarjeta extends FormaPago{

    private String num_tarjeta;
    private int mes_caducidad;
    private int año_caducidad;
    private int cod_seguridad;

    public Tarjeta(int id, String num_tarjeta, int mes_caducidad, int año_caducidad, int cod_seguridad) {
        super(id);
        this.num_tarjeta = num_tarjeta;
        this.mes_caducidad = mes_caducidad;
        this.año_caducidad = año_caducidad;
        this.cod_seguridad = cod_seguridad;
    }

    public String getNum_tarjeta() {
        return num_tarjeta;
    }

    public int getMes_caducidad() {
        return mes_caducidad;
    }

    public int getAño_caducidad() {
        return año_caducidad;
    }

    public int getCod_seguridad() {
        return cod_seguridad;
    }
}
