package Clases;

import java.sql.Date;

public class Eliminada extends Playlist{
    public Eliminada(int id, int usuario_id, String titulo, Date fecha_creacion) {
        super(id, usuario_id, titulo, fecha_creacion);
    }
}
