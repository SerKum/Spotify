package Clases;

public  abstract class FormaPago {

    private int id;

    public FormaPago(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
