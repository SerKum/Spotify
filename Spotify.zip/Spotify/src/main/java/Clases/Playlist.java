package Clases;

import java.util.ArrayList;
import java.sql.Date;

public abstract class Playlist {
    private int id;
    private int usuario_id;
    private String titulo;
    private Date fecha_creacion;

    ArrayList<Cancion>canciones = new ArrayList<>();

    public Playlist(int id, int usuario_id, String titulo, Date fecha_creacion) {
        this.id = id;
        this.usuario_id = usuario_id;
        this.titulo = titulo;
        this.fecha_creacion = fecha_creacion;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public int getId() {
        return id;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public ArrayList<Cancion> getCanciones() {
        return canciones;
    }

    public String getTitulo() {
        return titulo;
    }

    public void añadirCancion(Cancion c){
        canciones.add(c);
    }



}
