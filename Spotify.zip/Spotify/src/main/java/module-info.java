module spotify.spotify {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.datatransfer;
    requires java.desktop;
    requires java.sql;


    opens spotify.code to javafx.fxml;
    exports spotify.code;
}