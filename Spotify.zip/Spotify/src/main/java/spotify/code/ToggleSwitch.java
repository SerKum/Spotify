package spotify.code;

import javafx.animation.FillTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.Parent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class ToggleSwitch extends Parent {


    private BooleanProperty switchedOn = new SimpleBooleanProperty(false);

    private TranslateTransition translateAnimation = new TranslateTransition(Duration.seconds(0.25));

    private FillTransition fillAnimation = new FillTransition(Duration.seconds(0.25));

    private ParallelTransition animation = new ParallelTransition(translateAnimation, fillAnimation);


    public BooleanProperty switchedOnProperty() {
        return switchedOn;
    }

    public ToggleSwitch(Circle c ,Rectangle r) {
        r = new Rectangle(50, 25);
        r.setArcWidth(25);
        r.setArcHeight(25);
        r.setFill(Color.WHITE);
        r.setStroke(Color.LIGHTGRAY);

        c = new Circle(10);
        c.setCenterX(12);
        c.setCenterY(12);
        c.setFill(Color.WHITE);
        c.setStroke(Color.LIGHTGRAY);


        translateAnimation.setNode(c);
        fillAnimation.setShape(r);
        getChildren().addAll(r, c);

        switchedOn.addListener((obs,oldState,newState) ->{
            boolean isOn = newState.booleanValue();
            translateAnimation.setToX(isOn ? 50 - 25 : 0);
            fillAnimation.setFromValue(isOn ? Color.WHITE : Color.LIGHTGREEN);
            fillAnimation.setToValue(isOn ? Color.LIGHTGREEN : Color.WHITE);

            animation.play();
        });
        setOnMouseClicked(event -> {
            switchedOn.set(!switchedOn.get());
        });
    }
}