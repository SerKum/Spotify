package spotify.code;

import Clases.*;
import animations.*;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.net.URL;
import java.sql.*;
import java.util.*;

public class SpotifyController implements Initializable,Consultas{
    @FXML
    private AnchorPane panel;

    @FXML
    private AnchorPane panel1;

    @FXML
    private TextField username_text;

    @FXML
    private Button inicia_s;

    @FXML
    private PasswordField passwrd_text;

    @FXML
    private Pane alert_incorrect;

    @FXML
    private Pane alert_incompleted;

    @FXML
    private Rectangle sw_rect;

    @FXML
    private Circle sw_circ;

    @FXML
    private AnchorPane panel_registro;

    @FXML
    private TextField registro_username;

    @FXML
    private Pane alert_registroVacío;

    @FXML
    private Pane alert_usuarioExistente;

    @FXML
    private Pane alert_correoAsociado;

    @FXML
    private Rectangle sw_rect1;

    @FXML
    private Circle sw_circ1;

    @FXML
    private TextField registro_email;

    @FXML
    private ComboBox<String> combo_sexo;

    @FXML
    private DatePicker fecha_nacimiento;

    @FXML
    private TextField registro_país;

    @FXML
    private TextField registro_cp;

    @FXML
    private PasswordField registro_contraseña;

    @FXML
    private AnchorPane p_carga;

    @FXML
    private Circle loading_circle1;

    @FXML
    private Circle loading_circle2;

    @FXML
    private Circle loading_circle3;

    @FXML
    private Circle loading_circle4;

    @FXML
    private Text mensaje_carga;

    @FXML
    private AnchorPane panel_app;

    @FXML
    private MenuButton username_id;

    @FXML
    private MenuItem hazte_premium;

    @FXML
    private HBox home_button;

    @FXML
    private HBox explore_button;

    @FXML
    private HBox recently_button;

    @FXML
    private HBox liked_button;

    @FXML
    private HBox album_button;

    @FXML
    private HBox artists_button;

    @FXML
    private HBox podcasts_button;

    @FXML
    private HBox playlists_button;

    @FXML
    private HBox newp_button;

    @FXML
    private AnchorPane panel_principal;

    @FXML
    private ScrollPane scroll_pane;

    @FXML
    private AnchorPane all_panes;

    @FXML
    private AnchorPane inicio_app;

    @FXML
    private Label see_all1;

    @FXML
    private Label see_all2;

    @FXML
    private Label see_all3;

    @FXML
    private Pane playlist_home1;

    @FXML
    private Pane playlist_home2;

    @FXML
    private Pane playlist_home3;

    @FXML
    private Pane playlist_home4;

    @FXML
    private Pane playlist_home5;

    @FXML
    private Pane playlist_home6;

    @FXML
    private Pane playlist_home7;

    @FXML
    private Pane playlist_home8;

    @FXML
    private Pane playlist_home9;

    @FXML
    private Pane playlist_home10;

    @FXML
    private Pane playlist_home11;

    @FXML
    private Pane playlist_home12;

    @FXML
    private AnchorPane preview_button1;

    @FXML
    private AnchorPane patrocinadas_id;

    @FXML
    private Pane playlist_patrocinada_1;

    @FXML
    private Pane playlist_patrocinada_2;

    @FXML
    private Pane playlist_patrocinada_3;

    @FXML
    private Pane playlist_patrocinada_4;

    @FXML
    private Pane playlist_patrocinada_5;

    @FXML
    private Pane playlist_patrocinada_6;

    @FXML
    private Pane playlist_patrocinada_7;

    @FXML
    private Pane playlist_patrocinada_8;

    @FXML
    private Pane playlist_patrocinada_9;

    @FXML
    private Pane playlist_patrocinada_10;

    @FXML
    private Pane playlist_patrocinada_11;

    @FXML
    private Pane playlist_patrocinada_12;

    @FXML
    private Pane playlist_patrocinada_13;

    @FXML
    private Pane playlist_patrocinada_14;

    @FXML
    private Pane playlist_patrocinada_15;

    @FXML
    private Pane playlist_patrocinada_16;

    @FXML
    private AnchorPane explore_id;

    @FXML
    private AnchorPane recently_played;

    @FXML
    private AnchorPane liked_songs;

    @FXML
    private AnchorPane albums_id;

    @FXML
    private AnchorPane album_search;

    @FXML
    private TextField buscador_albumes;

    @FXML
    private AnchorPane selected_album;

    @FXML
    private Label titulo_album;

    @FXML
    private Label artista_album;

    @FXML
    private Label fecha_album;

    @FXML
    private AnchorPane artist_id;

    @FXML
    private AnchorPane all_artists;

    @FXML
    private TextField buscar_artistas;

    @FXML
    private AnchorPane selected_artist;

    @FXML
    private Label nombre_artista;

    @FXML
    private AnchorPane podcasts_id;

    @FXML
    private AnchorPane search_podcast;

    @FXML
    private TextField buscar_pod;

    @FXML
    private AnchorPane selected_podcast;

    @FXML
    private Label titulo_podcast;

    @FXML
    private ImageView foto_podcast;

    @FXML
    private Text descripcion_pod;

    @FXML
    private AnchorPane tus_playlists;

    @FXML
    private AnchorPane titulo_playlist;

    @FXML
    private TextField new_playlist_id;

    @FXML
    private Pane alert_playlist;

    @FXML
    private AnchorPane playlist_id;

    @FXML
    private Label playlist_title;

    @FXML
    private Label fecha_creacion;

    @FXML
    private AnchorPane configuracion_id;

    @FXML
    private CheckBox autoplay_checkbox;

    @FXML
    private CheckBox ajuste_checkbox;

    @FXML
    private CheckBox normalizacion_checkbox;

    @FXML
    private ComboBox<String> combo_tdescarga;

    @FXML
    private ComboBox<String> combo_calidad;

    @FXML
    private ComboBox<String> combo_idioma;

    @FXML
    private AnchorPane premium_ventana;

    @FXML
    private AnchorPane paypal_ventana;

    @FXML
    private TextField usuario_paypal;

    @FXML
    private Pane alert_usuarioPaypal_vacio;

    @FXML
    private Pane alert_usuarioPaypal_incorrect;

    @FXML
    private AnchorPane tarjeta_ventana;

    @FXML
    private TextField num_tarjeta;

    @FXML
    private TextField mes_caducidad;

    @FXML
    private TextField año_caducidad;

    @FXML
    private TextField cod_seguridad;

    @FXML
    private Pane alert_tarjeta_rellenar;

    @FXML
    private Pane alert_tarjeta_incorrect;

    @FXML
    private Pane barra_rep;

    @FXML
    private Button boton_reproduccion;

    @FXML
    private Button boton_seguir_album;

    @FXML
    private Button boton_noseguir_album;

    @FXML
    private Button boton_noseguir_artista;

    @FXML
    private Button boton_seguir_artista;

    @FXML
    private Button boton_seguir_podcast;

    @FXML
    private Button boton_noseguir_podcast;

    @FXML
    private Button boton_anyadir_cancion;

    @FXML
    private AnchorPane ventana_anyadir_cancion;
    
    @FXML 
    private TextField ventana_anyadir_buscar;

    @FXML
    private Label nombre_usuario_playlist;

    @FXML
    private Button boton_seguir_usuario;

    @FXML
    private ImageView icono_megusta_cancion;

    @FXML
    private ImageView icono_nomegusta_cancion;

    @FXML
    private Button boton_noseguir_usuario;

    @FXML
    private Button boton_noseguir_playlist;

    @FXML
    private Button boton_seguir_playlist;

    @FXML
    private VBox vbox_izquierda;

    @FXML
    private ImageView imagen_reproduciendo;

    @FXML
    private Label titulo_reproduciendo;

    @FXML
    private Label artista_reproduciendo;

    Usuario actual;

    ArrayList<Cancion> escuchado_recientemente_c = new ArrayList<>();

    ArrayList<Capitulo>escuchado_recientemente_p = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        todasCanciones();
        playlistsFavoritas();
        todosPodcasts();
        todosAlbums();
        todosArtistas();
        todosCapitulos();
        playlistsPatrocinadas();
        cancionesPlaylist();
        ToggleSwitch toggle = new ToggleSwitch(sw_circ,sw_rect);
        toggle.setTranslateX(918);
        toggle.setTranslateY(527);
        panel1.getChildren().add(toggle);
        combo_tdescarga.getItems().removeAll(combo_tdescarga.getItems());
        combo_tdescarga.getItems().addAll("Automático","Baja","Normal","Alta","Muy Alta");
        combo_idioma.getItems().removeAll(combo_idioma.getItems());
        combo_idioma.getItems().addAll("Español","Inglés","Francés","Italiano","Alemán");
        combo_calidad.getItems().removeAll(combo_calidad.getItems());
        combo_calidad.getItems().addAll("Automático","Baja","Normal","Alta","Muy Alta");
        combo_sexo.getItems().removeAll(combo_sexo.getItems());
        combo_sexo.getItems().addAll("M","F");
        int s=0;
        for (Node m : inicio_app.getChildren()){
            if (m instanceof AnchorPane){

            }
            else if (m instanceof Pane){
                m.setId(String.valueOf(lista_patrocinadas.get(s).getId()));
                Label t = new Label();
                t.setLayoutX(33);
                t.setLayoutY(262);
                t.getStyleClass().add("app-home-playlist-title");
                ((Pane)m).getChildren().add(t);
                for( Node c :((Pane)m).getChildren()){
                    if (c instanceof Label) {
                        ((Label) c).setText(lista_patrocinadas.get(s).getTitulo());
                    }
                }
                if (s == 3 || s == 19 ){
                    s+=12;
                }
                s++;
            }
        }
        for ( Node a: patrocinadas_id.getChildren()){
            Label t = new Label();
            t.setLayoutX(20);
            t.setLayoutY(167);
            t.getStyleClass().add("app-home-playlist-artists");
            ((Pane)a).getChildren().add(t);
        }
    }


    @FXML
    private void setInicia_s(ActionEvent e){
        tarjetas();
        usuariosPaypal();
        usuariosPremium();
        usuariosFree();
        animacionesB(inicia_s);
        if (comprobarInicio()){
            mensaje_carga.setText("Cargando...");
            username_id.setText(username_text.getText());
            panel1.setVisible(false);
            p_carga.setVisible(true);
            new FadeIn(p_carga).play();
            animacionCarga();
            Timer timer = new Timer();
            TimerTask tarea = new TimerTask() {
                @Override
                public void run() {
                    p_carga.setVisible(false);
                    panel_app.setVisible(true);
                    new FadeIn(panel_app).play();
                }
            };
            timer.schedule(tarea,5000);
            actual.getUsername();
        };
        if (usuarios_premium.contains(actual)){
            hazte_premium.setVisible(false);
        }
        else if (usuarios_free.contains(actual)){
            hazte_premium.setVisible(true);
        }
    }
    public void animacionesB(Button control) {
        new FadeIn(inicia_s).play();
        new Pulse(inicia_s).play();
    }
    public void animacionCarga(){
        new Bounce(loading_circle1).setCycleCount(4).setDelay(Duration.millis(100)).play();
        new Bounce(loading_circle2).setCycleCount(4).setDelay(Duration.millis(200)).play();
        new Bounce(loading_circle3).setCycleCount(4).setDelay(Duration.millis(400)).play();
        new Bounce(loading_circle4).setCycleCount(4).setDelay(Duration.millis(800)).play();
    }

    public boolean comprobarInicio(){
        if (username_text.getText().isBlank() || passwrd_text.getText().isBlank()){
            alertasInicio(1);
            return false;
        }


        if (!validarUsuario()){
            alertasInicio(2);
            return false;
        }
        return true;
    }

    public boolean validarUsuario(){
        for (Usuario u : usuarios_premium){
            if (username_text.getText().equals(u.getUsername()) && passwrd_text.getText().equals(u.getPassword())){
                actual = u;
                return true;
            }
        }
        for (Usuario us : usuarios_free){
            if (username_text.getText().equals(us.getUsername()) && passwrd_text.getText().equals(us.getPassword())){
                actual = us;
                return true;
            }
        }
        return false;
    }

    public void alertasInicio(int i){
        switch (i){
            case 1:
                alert_incorrect.setVisible(false);
                alert_incompleted.setVisible(true);
                new Shake(alert_incompleted).play();
                break;
            case 2:
                alert_incompleted.setVisible(false);
                alert_incorrect.setVisible(true);
                new Shake(alert_incorrect).play();
                break;
        }
    }

    public void animacionHB(MouseEvent mouseEvent) {
        Node pp = mouseEvent.getPickResult().getIntersectedNode();
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                new ZoomIn(pp).play();
            }
        };
        timer.schedule(task,1);
        cambioPaneles();
        switch (pp.getId()){
            case "home_button":
                inicio_app.setVisible(true);
                break;
            case "explore_button":
                explore_id.setVisible(true);
                break;
            case "recently_button":
                recently_played.setVisible(true);
                escuchadoRecientemente();
                break;
            case "liked_button":
                liked_songs.setVisible(true);
                likedSongs();
                break;
            case "album_button":
                albums_id.setVisible(true);
                tusAlbumes();
                break;
            case "artists_button":
                artist_id.setVisible(true);
                tusArtistas();
                break;
            case "podcasts_button":
                podcasts_id.setVisible(true);
                tusPodcasts();
                break;
            case "playlists_button":
                tus_playlists.setVisible(true);
                tusPlaylists();
                break;
            case "newp_button":
                titulo_playlist.setVisible(true);
                break;
        }
    }

    public void animacionPreview(MouseEvent mouseEvent){
        Node pp = mouseEvent.getPickResult().getIntersectedNode();
        preview_button1.setLayoutX(pp.getLayoutX() + 35);
        preview_button1.setLayoutY(pp.getLayoutY() + 30);
        preview_button1.setVisible(true);
        new FadeInUp(preview_button1).setSpeed(2).play();
    }

    public void tusPlaylists(){
        tus_playlists.getChildren().removeIf(node -> node instanceof Pane);
        playlistsActivas();
        tusPlaylists(actual.getId());
        int layX = 55; int layY= 247;
        for ( Playlist p : playlists_propias){
            Pane panel = new Pane();
            Rectangle rectangle = new Rectangle();
            Label titulo = new Label();
            panel.getStyleClass().add("app-home-preview-playlist");
            rectangle.getStyleClass().add("app-home-preview-image");
            titulo.getStyleClass().add("app-home-playlist-title");
            titulo.setMouseTransparent(true);
            rectangle.setMouseTransparent(true);
            panel.setPrefWidth(231);
            panel.setPrefHeight(299);
            panel.setLayoutX(layX);
            panel.setLayoutY(layY);
            panel.setId(String.valueOf(p.getId()));
            EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    playlist_id.getChildren().removeIf(node -> node instanceof Pane);
                    boton_seguir_playlist.setVisible(false);
                    boton_noseguir_playlist.setVisible(false);
                    nombre_usuario_playlist.setVisible(false);
                    boton_seguir_usuario.setVisible(false);
                    boton_noseguir_usuario.setVisible(false);
                    Playlist p_actual = null;
                    for (Playlist pl :playlists_propias ){
                        if (p.getId() == pl.getId()){
                            p_actual=pl;
                        }
                    }
                    boton_anyadir_cancion.setVisible(true);
                    cambioPaneles();
                    playlist_id.setVisible(true);
                    playlist_id.setId(String.valueOf(p_actual.getId()));
                    playlist_title.setText(p_actual.getTitulo());
                    fecha_creacion.setText("Fecha creación : "+p.getFecha_creacion().toString());
                    int escaladoY = 229;
                    for(Cancion c : p_actual.getCanciones()){
                        Pane pa = new Pane();
                        ImageView im= new ImageView();
                        Label l = new Label();
                        Label l2 = new Label();
                        Button eliminar = new Button();
                        Separator se = new Separator();
                        l.getStyleClass().add("titulos-canciones");
                        l2.getStyleClass().add("titulos-canciones");
                        pa.getStyleClass().add("paneles");
                        se.getStyleClass().add("separadores");
                        im.getStyleClass().add("imagenes-canciones");
                        eliminar.getStyleClass().add("boton-eliminar-playlist");
                        l.setText(c.getTitulo());
                        l2.setText(sacarArtistas(c.getAlbum_id()));
                        im.setFitWidth(74);
                        im.setFitHeight(66);
                        im.setLayoutX(5);
                        im.setLayoutY(5);
                        l.setLayoutX(209);
                        l.setLayoutY(32);
                        l2.setLayoutX(802);
                        l2.setLayoutY(32);
                        eliminar.setLayoutX(1102);
                        eliminar.setLayoutY(23);
                        eliminar.setText("X");
                        Playlist finalP_actual = p_actual;
                        eliminar.setOnAction(event -> {
                            eliminarCancionPlaylist(finalP_actual.getId(),c.getId());
                            playlistsActivas();
                            tusPlaylists();
                            handle(mouseEvent);
                        });
                        se.setLayoutX(0);
                        se.setLayoutY(80);
                        pa.setId(String.valueOf(c.getId()));
                        pa.setLayoutX(51);
                        pa.setLayoutY(escaladoY);
                        pa.getChildren().addAll(im,l,l2,se,eliminar);
                        pa.setOnMouseClicked(event -> {
                            escuchado_recientemente_c.add(c);
                            barra_rep.setVisible(true);
                            barra_rep.setId(String.valueOf(c.getId()));
                            for (Playlist play : lista_favoritas){
                                if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                                    icono_megusta_cancion.setVisible(true);
                                    icono_nomegusta_cancion.setVisible(false);
                                    break;
                                }
                                else{
                                    icono_megusta_cancion.setVisible(false);
                                    icono_nomegusta_cancion.setVisible(true);
                                    break;
                                }
                            }
                            vbox_izquierda.setPrefHeight(731);
                            scroll_pane.setPrefHeight(658);
                            titulo_reproduciendo.setText(c.getTitulo());
                            for (Album a : all_albums){
                                if (c.getAlbum_id() == a.getId()){
                                    for (Artista ar : listaA){
                                        if (a.getArtista_id() == ar.getId()){
                                            artista_reproduciendo.setText(ar.getNombre());
                                        }
                                    }
                                }
                            }
                            imagen_reproduciendo.setImage(im.getImage());
                        });
                        playlist_id.getChildren().add(pa);
                        escaladoY+=80;
                    }
                    Pane pane = new Pane();
                    pane.setLayoutY(escaladoY+200);
                    playlist_id.getChildren().add(pane);
                }
            };
            panel.addEventFilter(MouseEvent.MOUSE_CLICKED,eventHandler);
            rectangle.setLayoutX(16);
            rectangle.setLayoutY(14);
            rectangle.setWidth(200);
            rectangle.setHeight(200);
            titulo.setLayoutX(24);
            titulo.setLayoutY(239);
            titulo.setText(p.getTitulo());
            panel.getChildren().addAll(rectangle,titulo);
            tus_playlists.getChildren().add(panel);
            if (layX < 369){
                layX+=314;
            }
            else if (layX == 369){
                layX=55;
                layY+=353;
            }
        }
        Pane rebasar = new Pane();
        rebasar.setLayoutY(layY+500);
        tus_playlists.getChildren().add(rebasar);
        playlistSeguidas(actual.getId());
        int lX = 687; int lY = 247;
        for (Playlist pl : playlist_seguidas){
            Pane pan = new Pane();
            Rectangle rec = new Rectangle();
            Label tit = new Label();
            pan.getStyleClass().add("app-home-preview-playlist");
            rec.getStyleClass().add("app-home-preview-image");
            tit.getStyleClass().add("app-home-playlist-title");
            rec.setMouseTransparent(true);
            tit.setMouseTransparent(true);
            pan.setPrefWidth(231);
            pan.setPrefHeight(299);
            pan.setLayoutX(lX);
            pan.setLayoutY(lY);
            pan.setId(String.valueOf(pl.getId()));
            EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    playlist_id.getChildren().removeIf(node -> node instanceof Pane);
                    boton_anyadir_cancion.setVisible(false);
                    if (pl.getUsuario_id() == actual.getId()){
                        boton_seguir_playlist.setVisible(false);
                        boton_noseguir_playlist.setVisible(false);
                    }
                    else{
                        boton_seguir_playlist.setVisible(false);
                        boton_noseguir_playlist.setVisible(true);
                    }
                    sigueUsuario(actual.getId());
                    boolean sigueUsuario=false;
                    for (Usuario u: usuarios_seguidos){
                        if (u.getId() == pl.getUsuario_id()){
                            sigueUsuario=true;
                        }
                    }
                    if (sigueUsuario==true){
                        nombre_usuario_playlist.setVisible(true);
                        nombre_usuario_playlist.setId(String.valueOf(pl.getUsuario_id()));
                        for (Usuario u : all_users){
                            if (u.getId() == pl.getUsuario_id()){
                                nombre_usuario_playlist.setText(u.getUsername());
                            }
                        }
                        boton_seguir_usuario.setVisible(false);
                        boton_noseguir_usuario.setVisible(true);
                    }
                    else if (sigueUsuario == false){
                        nombre_usuario_playlist.setVisible(true);
                        nombre_usuario_playlist.setId(String.valueOf(pl.getUsuario_id()));
                        for (Usuario u : all_users){
                            if (u.getId() == pl.getUsuario_id()){
                                nombre_usuario_playlist.setText(u.getUsername());
                            }
                        }
                        boton_seguir_usuario.setVisible(true);
                        boton_noseguir_usuario.setVisible(false);
                    }
                    cambioPaneles();
                    playlist_id.setId(String.valueOf(pl.getId()));
                    playlist_id.setVisible(true);
                    playlist_title.setText(pl.getTitulo());
                    fecha_creacion.setText("Fecha creación : "+pl.getFecha_creacion().toString());
                    int escaladoY = 229;
                    for(Cancion c : pl.getCanciones()){
                        Pane pa = new Pane();
                        ImageView im= new ImageView();
                        Label l = new Label();
                        Label l2 = new Label();
                        Separator se = new Separator();
                        l.getStyleClass().add("titulos-canciones");
                        l2.getStyleClass().add("titulos-canciones");
                        pa.getStyleClass().add("paneles");
                        se.getStyleClass().add("separadores");
                        im.getStyleClass().add("imagenes-canciones");
                        l.setText(c.getTitulo());
                        l2.setText(sacarArtistas(c.getAlbum_id()));
                        im.setFitWidth(74);
                        im.setFitHeight(66);
                        im.setLayoutX(5);
                        im.setLayoutY(5);
                        l.setLayoutX(209);
                        l.setLayoutY(32);
                        l2.setLayoutX(802);
                        l2.setLayoutY(32);
                        se.setLayoutX(0);
                        se.setLayoutY(80);
                        pa.setId(String.valueOf(c.getId()));
                        pa.setLayoutX(51);
                        pa.setLayoutY(escaladoY);
                        pa.setOnMouseClicked(event -> {
                            escuchado_recientemente_c.add(c);
                            barra_rep.setVisible(true);
                            barra_rep.setId(String.valueOf(c.getId()));
                            for (Playlist play : lista_favoritas){
                                if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                                    icono_megusta_cancion.setVisible(true);
                                    icono_nomegusta_cancion.setVisible(false);
                                    break;
                                }
                                else{
                                    icono_megusta_cancion.setVisible(false);
                                    icono_nomegusta_cancion.setVisible(true);
                                    break;
                                }
                            }
                            vbox_izquierda.setPrefHeight(731);
                            scroll_pane.setPrefHeight(658);
                            titulo_reproduciendo.setText(c.getTitulo());
                            for (Album a : all_albums){
                                if (c.getAlbum_id() == a.getId()){
                                    for (Artista ar : listaA){
                                        if (a.getArtista_id() == ar.getId()){
                                            artista_reproduciendo.setText(ar.getNombre());
                                        }
                                    }
                                }
                            }
                            imagen_reproduciendo.setImage(im.getImage());
                        });
                        pa.getChildren().addAll(im,l,l2,se);
                        playlist_id.getChildren().add(pa);
                        escaladoY+=80;
                    }
                    Pane pane = new Pane();
                    pane.setLayoutY(escaladoY+200);
                    playlist_id.getChildren().add(pane);
                }
            };
            pan.addEventFilter(MouseEvent.MOUSE_CLICKED,eventHandler);
            rec.setLayoutX(16);
            rec.setLayoutY(14);
            rec.setWidth(200);
            rec.setHeight(200);
            tit.setLayoutX(24);
            tit.setLayoutY(239);
            tit.setText(pl.getTitulo());
            pan.getChildren().addAll(rec,tit);
            tus_playlists.getChildren().add(pan);
            if (lX < 1001){
                lX+=314;
            }
            else if (lX == 1001){
                lX=687;
                lY+=353;
            }
        }
        Pane espacio= new Pane();
        rebasar.setLayoutY(lY+500);
        tus_playlists.getChildren().add(espacio);
    }


    public void cambioPaneles(){
        for ( Node n : all_panes.getChildren()){
            if (n.isVisible()){
                if (((AnchorPane)n).getHeight() > 1550.4){
                    ((AnchorPane)n).getChildren().removeIf(node -> node instanceof Pane);
                }
                n.setVisible(false);
            }
        }
        alert_tarjeta_rellenar.setVisible(false);
        alert_tarjeta_incorrect.setVisible(false);
        alert_playlist.setVisible(false);
        alert_usuarioPaypal_vacio.setVisible(false);
        alert_usuarioPaypal_incorrect.setVisible(false);
        scroll_pane.setVvalue(0);
    }

    public void tusPodcasts(){
        podcasts_id.getChildren().removeIf(node -> node instanceof Pane);
        podcastsSeguidos(actual.getId());
        int layX = 51; int layY = 620;
        for (Podcasts p : podcasts_seguidos){
            Pane pane = new Pane();
            ImageView foto = new ImageView();
            Label titulo = new Label();
            Text año = new Text();
            pane.getStyleClass().add("podcasts");
            foto.getStyleClass().add("fotos-podcasts");
            titulo.getStyleClass().add("titulos-podcasts");
            año.getStyleClass().add("descripcion-podcasts");
            pane.setLayoutX(layX);
            pane.setLayoutY(layY);
            pane.setId(String.valueOf(p.getId()));
            pane.setOnMouseClicked(event -> {
                selected_podcast.getChildren().removeIf(node -> node instanceof Pane);
                cambioPaneles();
                selected_podcast.setVisible(true);
                selected_podcast.setId(String.valueOf(p.getId()));
                titulo_podcast.setText(p.getTitulo());
                descripcion_pod.setText(p.getDescripción());
                int escaladoY = 427;
                for (Capitulo c : all_chapters){
                    if (String.valueOf(c.getPodcast_id()).equals(pane.getId())){
                        Pane p_cap = new Pane();
                        Label titulo_cap = new Label();
                        Label descripcion_cap = new Label();
                        Label fecha_cap = new Label();
                        Separator separator = new Separator();
                        separator.getStyleClass().add("separadores");
                        p_cap.getStyleClass().add("capitulos");
                        titulo_cap.getStyleClass().add("titulos-capitulos");
                        descripcion_cap.getStyleClass().add("descripcion-capitulos");
                        fecha_cap.getStyleClass().add("app-subtitle-labels");
                        p_cap.setLayoutX(62);
                        p_cap.setLayoutY(escaladoY);
                        separator.setLayoutY(161);
                        titulo_cap.setLayoutX(43);
                        titulo_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(titulo_cap.heightProperty()).divide(2));
                        titulo_cap.setWrapText(true);
                        titulo_cap.setText(c.getTitulo());
                        descripcion_cap.setLayoutX(309);
                        descripcion_cap.setWrapText(true);
                        descripcion_cap.setPrefHeight(200);
                        descripcion_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(descripcion_cap.heightProperty()).divide(2));
                        descripcion_cap.setText(c.getDescripcion());
                        fecha_cap.setLayoutX(1056);
                        fecha_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(fecha_cap.heightProperty()).divide(2));
                        fecha_cap.setText(c.getFecha().toString());
                        p_cap.setOnMouseClicked(event1 -> {
                            escuchado_recientemente_p.add(c);
                            barra_rep.setVisible(true);
                            icono_nomegusta_cancion.setVisible(false);
                            icono_megusta_cancion.setVisible(false);
                            vbox_izquierda.setPrefHeight(731);
                            scroll_pane.setPrefHeight(658);
                            titulo_reproduciendo.setText(c.getTitulo());
                            artista_reproduciendo.setText(" ");
                            imagen_reproduciendo.setImage(foto.getImage());
                        });
                        p_cap.getChildren().addAll(titulo_cap,descripcion_cap,fecha_cap,separator);
                        selected_podcast.getChildren().add(p_cap);
                        escaladoY+=161;
                    }
                }
                Pane espacio_abajo = new Pane();
                espacio_abajo.setLayoutY(escaladoY+200);
                selected_podcast.getChildren().add(espacio_abajo);
            });
            foto.setLayoutX(14);
            foto.setLayoutY(14);
            foto.setFitWidth(192);
            foto.setFitHeight(196);
            titulo.setLayoutX(222);
            titulo.setLayoutY(14);
            titulo.setWrapText(true);
            titulo.setText(p.getTitulo());
            año.setLayoutX(220);
            año.setLayoutY(116);
            año.setText("Año : "+String.valueOf(p.getAño()));
            pane.getChildren().addAll(foto,titulo,año);
            podcasts_id.getChildren().add(pane);
            if (layX < 664){
                layX+=613;
            }
            else if (layX == 664){
                layX=51;
                layY+=290;
            }
        }
        Pane rebasar = new Pane();
        rebasar.setLayoutY(layY+500);
        podcasts_id.getChildren().add(rebasar);
    }

    public void tusAlbumes(){
        albums_id.getChildren().removeIf(node -> node instanceof Pane);
        albumesSeguidos(actual.getId());
        int escaladoX = 47; int escaladoY = 620;
        for (Album a : album_seguidos){
            Pane panel = new Pane();
            ImageView foto = new ImageView();
            Label titulo = new Label();
            Label artista = new Label();
            panel.getStyleClass().add("albumes");
            foto.getStyleClass().add("fotos-albumes");
            titulo.getStyleClass().add("artista-titulo-albumes");
            artista.getStyleClass().add("artista-titulo-albumes");
            titulo.setText(a.getTitulo());
            artista.setText(sacarArtistas(a.getId()));
            panel.setLayoutX(escaladoX);
            panel.setLayoutY(escaladoY);
            panel.setId(String.valueOf(a.getId()));
            panel.setOnMouseClicked( event -> {
                selected_album.getChildren().removeIf(node -> node instanceof Pane);
                cambioPaneles();
                selected_album.setVisible(true);
                selected_album.setId(String.valueOf(a.getId()));
                boton_noseguir_album.setVisible(true);
                boton_seguir_album.setVisible(false);
                titulo_album.setText(titulo.getText());
                artista_album.setText(artista.getText());
                fecha_album.setText("Año : "+a.getAño());
                int layY = 424;
                for (Cancion c : all_songs) {
                    if (String.valueOf(c.getAlbum_id()).equals(panel.getId())){
                        Pane pane = new Pane();
                        Label titulo_c = new Label();
                        ImageView foto_cancion = new ImageView();
                        Separator separator = new Separator();
                        pane.getStyleClass().add("albumes-canciones");
                        titulo_c.getStyleClass().add("titulos-canciones");
                        foto_cancion.getStyleClass().add("imagenes-canciones");
                        separator.getStyleClass().add("separadores");
                        separator.setLayoutY(80);
                        pane.setLayoutX(62);
                        pane.setLayoutY(layY);
                        pane.setId(String.valueOf(c.getId()));
                        foto_cancion.setLayoutX(24);
                        foto_cancion.setLayoutY(10);
                        foto_cancion.setFitWidth(74);
                        foto_cancion.setFitHeight(66);
                        titulo_c.setLayoutX(208);
                        titulo_c.setLayoutY(30);
                        titulo_c.setText(c.getTitulo());
                        pane.setOnMouseClicked( event2 -> {
                            escuchado_recientemente_c.add(c);
                            barra_rep.setVisible(true);
                            barra_rep.setId(String.valueOf(c.getId()));
                            for (Playlist play : lista_favoritas){
                                if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                                    icono_megusta_cancion.setVisible(true);
                                    icono_nomegusta_cancion.setVisible(false);
                                    break;
                                }
                                else{
                                    icono_megusta_cancion.setVisible(false);
                                    icono_nomegusta_cancion.setVisible(true);
                                    break;
                                }
                            }
                            vbox_izquierda.setPrefHeight(731);
                            scroll_pane.setPrefHeight(658);
                            titulo_reproduciendo.setText(c.getTitulo());
                            for (Album al : all_albums){
                                if (c.getAlbum_id() == al.getId()){
                                    for (Artista ar : listaA){
                                        if (al.getArtista_id() == ar.getId()){
                                            artista_reproduciendo.setText(ar.getNombre());
                                        }
                                    }
                                }
                            }
                            imagen_reproduciendo.setImage(foto_cancion.getImage());
                        });
                        pane.getChildren().addAll(titulo_c,foto_cancion,separator);
                        selected_album.getChildren().add(pane);
                        layY+=80;
                    }
                }
                Pane ajuste = new Pane();
                ajuste.setLayoutY(layY+200);
                selected_album.getChildren().add(ajuste);
            });
            foto.setFitWidth(343);
            foto.setFitHeight(350);
            foto.setLayoutX(4);
            foto.setLayoutY(4);
            titulo.setLayoutX(14);
            titulo.setLayoutY(361);
            artista.setLayoutX(14);
            artista.setLayoutY(398);
            panel.getChildren().addAll(foto,titulo,artista);
            albums_id.getChildren().add(panel);
            if (escaladoX < 873) {
                escaladoX += 413;
            }
            else if (escaladoX == 873){
                escaladoX=47;
                escaladoY+=500;
            }
        }
        Pane pane_a = new Pane();
        pane_a.setLayoutY(escaladoY+600);
        albums_id.getChildren().add(pane_a);
    }

    public void tusArtistas(){
        artist_id.getChildren().removeIf(node -> node instanceof Pane);
        artistasSeguidos(actual.getId());
        int layX = 50 ; int layY = 620 ;
        for (Artista a : artistas_seguidos){
            Pane pane = new Pane();
            Circle foto = new Circle();
            Label nombre = new Label();
            pane.getStyleClass().add("artistas");
            foto.getStyleClass().add("foto-artistas");
            nombre.getStyleClass().add("artista-titulo-albumes");
            nombre.setText(a.getNombre());
            pane.setLayoutX(layX);
            pane.setLayoutY(layY);
            pane.setId(String.valueOf(a.getId()));
            pane.setOnMouseClicked(event -> {
                selected_artist.getChildren().removeIf(node -> node instanceof Pane);
                cambioPaneles();
                selected_artist.setVisible(true);
                selected_artist.setId(String.valueOf(a.getId()));
                boton_seguir_artista.setVisible(false);
                boton_noseguir_artista.setVisible(true);
                nombre_artista.setText(a.getNombre());
                int escaladoY = 424;
                for (Album al :all_albums){
                    if (a.getId() == al.getArtista_id()){
                        for (Cancion ca : all_songs){
                            if (al.getId() == ca.getAlbum_id()){
                                Pane pane_c = new Pane();
                                Separator sep = new Separator();
                                ImageView foto_c = new ImageView();
                                Label titulo = new Label();
                                Label album = new Label();
                                pane_c.getStyleClass().add("canciones-albums-artistas");
                                foto_c.getStyleClass().add("imagenes-canciones");
                                titulo.getStyleClass().add("titulos-canciones");
                                album.getStyleClass().add("titulos-canciones");
                                sep.getStyleClass().add("separadores");
                                sep.setLayoutY(103);
                                pane_c.setLayoutX(68);
                                pane_c.setLayoutY(escaladoY);
                                foto_c.setLayoutX(14);
                                foto_c.setLayoutY(7);
                                foto_c.setFitWidth(94);
                                foto_c.setFitHeight(90);
                                titulo.setLayoutX(195);
                                titulo.setLayoutY(41);
                                titulo.setText(ca.getTitulo());
                                album.setLayoutX(760);
                                album.setLayoutY(41);
                                album.setText(al.getTitulo());
                                pane_c.setOnMouseClicked(event1 -> {
                                    escuchado_recientemente_c.add(ca);
                                    barra_rep.setVisible(true);
                                    barra_rep.setId(String.valueOf(ca.getId()));
                                    for (Playlist play : lista_favoritas){
                                        if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(ca)){
                                            icono_megusta_cancion.setVisible(true);
                                            icono_nomegusta_cancion.setVisible(false);
                                            break;
                                        }
                                        else{
                                            icono_megusta_cancion.setVisible(false);
                                            icono_nomegusta_cancion.setVisible(true);
                                            break;
                                        }
                                    }
                                    vbox_izquierda.setPrefHeight(731);
                                    scroll_pane.setPrefHeight(658);
                                    titulo_reproduciendo.setText(ca.getTitulo());
                                    for (Album alb : all_albums){
                                        if (ca.getAlbum_id() == alb.getId()){
                                            for (Artista ar : listaA){
                                                if (alb.getArtista_id() == ar.getId()){
                                                    artista_reproduciendo.setText(ar.getNombre());
                                                }
                                            }
                                        }
                                    }
                                    imagen_reproduciendo.setImage(foto_c.getImage());
                                });
                                pane_c.getChildren().addAll(foto_c,titulo,album,sep);
                                selected_artist.getChildren().add(pane_c);
                                escaladoY+=113;
                            }
                        }
                    }
                }
                Pane espaciado = new Pane();
                espaciado.setLayoutY(escaladoY+200);
                selected_artist.getChildren().add(espaciado);
            });
            foto.setRadius(120);
            foto.setLayoutX(150);
            foto.setLayoutY(146);
            nombre.layoutXProperty().bind(pane.widthProperty().subtract(nombre.widthProperty()).divide(2));
            nombre.setLayoutY(316);
            pane.getChildren().addAll(foto,nombre);
            artist_id.getChildren().add(pane);
            if (layX < 930){
                layX+=440;
            }
            else if (layX == 930){
                layX=50;
                layY+=400;
            }
        }
        Pane rebasar = new Pane();
        rebasar.setLayoutY(layY+600);
        artist_id.getChildren().add(rebasar);
    }


    public void animacionPreviewE(MouseEvent mouseEvent) {
        preview_button1.setVisible(false);
    }

    public void scaleBoton(MouseEvent mouseEvent) {
        preview_button1.setScaleX(0.7);
        preview_button1.setScaleY(0.7);
    }

    public void releaseBoton(MouseEvent mouseEvent) {
        preview_button1.setScaleX(1);
        preview_button1.setScaleY(1);
    }

    public void log_out(ActionEvent actionEvent) {
        cambioPaneles();
        inicio_app.setVisible(true);
        barra_rep.setVisible(false);
        vbox_izquierda.setPrefHeight(900);
        scroll_pane.setPrefHeight(830);
        panel_app.setVisible(false);
        username_text.clear();
        passwrd_text.clear();
        mensaje_carga.setText("Saliendo...");
        p_carga.setVisible(true);
        new FadeIn(p_carga).play();
        animacionCarga();
        Timer timer = new Timer();
        TimerTask tarea = new TimerTask() {
            @Override
            public void run() {
                p_carga.setVisible(false);
                panel1.setVisible(true);
                new FadeIn(panel1).play();
            }
        };
        timer.schedule(tarea,5000);
    }

    public void settings(ActionEvent actionEvent) {
        cambioPaneles();
        configuracion_id.setVisible(true);
    }

    public Connection conexion() throws SQLException {
         Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify","root","dbrootpass");
         return con;
    }

    public void patrocinadasVerTodo(Event event) {
        cambioPaneles();
        patrocinadas_id.setVisible(true);
        switch (((Control)event.getSource()).getId()){
            case "see_all1":
                playlistPatrocinadasInicio(0);
                break;
            case "see_all2":
                playlistPatrocinadasInicio(16);
                break;
            case "see_all3":
                playlistPatrocinadasInicio(32);
                break;
        }
    }

    public void playlistPatrocinadasInicio(int inicio){
        for(Node n :  patrocinadas_id.getChildren()){
            n.setId(String.valueOf(lista_patrocinadas.get(inicio).getId()));
            for( Node e :((Pane)n).getChildren()){
                if (e instanceof Label) {
                    ((Label) e).setText(lista_patrocinadas.get(inicio).getTitulo());
                }
            }
            inicio++;
        }
    }


    public void verPlaylist(MouseEvent mouseEvent){
        playlist_id.getChildren().removeIf(node -> node instanceof Pane);
        String id = mouseEvent.getPickResult().getIntersectedNode().getId();
        boton_anyadir_cancion.setVisible(false);
        playlistSeguidas(actual.getId());
        Playlist p_actual = null;
        for (Playlist p : lista_patrocinadas){
            if (p.getId() == Integer.parseInt(id)){
                p_actual = p;
            }
        }
        if (p_actual.getUsuario_id() == actual.getId()){
            boton_seguir_playlist.setVisible(false);
            boton_noseguir_playlist.setVisible(false);
        }
        else{
            sigueUsuario(actual.getId());
            boolean sigueUsuario=false;
            for (Usuario u: usuarios_seguidos){
                if (u.getId() == p_actual.getUsuario_id()){
                    sigueUsuario=true;
                }
            }
            if (sigueUsuario==true){
                nombre_usuario_playlist.setVisible(true);
                nombre_usuario_playlist.setId(String.valueOf(p_actual.getUsuario_id()));
                for (Usuario u : all_users){
                    if (u.getId() == p_actual.getUsuario_id()){
                        nombre_usuario_playlist.setText(u.getUsername());
                    }
                }
                boton_seguir_usuario.setVisible(false);
                boton_noseguir_usuario.setVisible(true);
            }
            else if (sigueUsuario == false){
                nombre_usuario_playlist.setVisible(true);
                nombre_usuario_playlist.setId(String.valueOf(p_actual.getUsuario_id()));
                for (Usuario u : all_users){
                    if (u.getId() == p_actual.getUsuario_id()){
                        nombre_usuario_playlist.setText(u.getUsername());
                    }
                }
                boton_seguir_usuario.setVisible(true);
                boton_noseguir_usuario.setVisible(false);
            }
            if (playlist_seguidas.contains(p_actual)){
                boton_seguir_playlist.setVisible(false);
                boton_noseguir_playlist.setVisible(true);
            }
            else{
                boton_seguir_playlist.setVisible(true);
                boton_noseguir_playlist.setVisible(false);
            }
        }
        cambioPaneles();
        playlist_id.setVisible(true);
        playlist_id.setId(String.valueOf(p_actual.getId()));
        playlist_title.setText(p_actual.getTitulo());
        fecha_creacion.setText("Fecha creación : "+p_actual.getFecha_creacion().toString());
        int escaladoY = 229;
        for(Cancion c : p_actual.getCanciones()){
            Pane pa = new Pane();
            ImageView im= new ImageView();
            Label l = new Label();
            Label l2 = new Label();
            Separator se = new Separator();
            l.getStyleClass().add("titulos-canciones");
            l2.getStyleClass().add("titulos-canciones");
            pa.getStyleClass().add("paneles");
            se.getStyleClass().add("separadores");
            im.getStyleClass().add("imagenes-canciones");
            l.setText(c.getTitulo());
            l2.setText(sacarArtistas(c.getAlbum_id()));
            im.setFitWidth(74);
            im.setFitHeight(66);
            im.setLayoutX(5);
            im.setLayoutY(5);
            l.setLayoutX(209);
            l.setLayoutY(32);
            l2.setLayoutX(802);
            l2.setLayoutY(32);
            se.setLayoutX(0);
            se.setLayoutY(80);
            pa.setId(String.valueOf(c.getId()));
            pa.setLayoutX(51);
            pa.setLayoutY(escaladoY);
            pa.getChildren().addAll(im,l,l2,se);
            pa.setOnMouseClicked(event -> {
                escuchado_recientemente_c.add(c);
                barra_rep.setVisible(true);
                barra_rep.setId(String.valueOf(c.getId()));
                for (Playlist play : lista_favoritas){
                    if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                        icono_megusta_cancion.setVisible(true);
                        icono_nomegusta_cancion.setVisible(false);
                        break;
                    }
                    else{
                        icono_megusta_cancion.setVisible(false);
                        icono_nomegusta_cancion.setVisible(true);
                        break;
                    }
                }
                vbox_izquierda.setPrefHeight(731);
                scroll_pane.setPrefHeight(658);
                titulo_reproduciendo.setText(c.getTitulo());
                for (Album a : all_albums){
                    if (c.getAlbum_id() == a.getId()){
                        for (Artista ar : listaA){
                            if (a.getArtista_id() == ar.getId()){
                                artista_reproduciendo.setText(ar.getNombre());
                            }
                        }
                    }
                }
                imagen_reproduciendo.setImage(im.getImage());
            });
            playlist_id.getChildren().add(pa);
            escaladoY+=80;
        }
        Pane pane = new Pane();
        pane.setLayoutY(escaladoY+200);
        playlist_id.getChildren().add(pane);
    }


    public void playPause(MouseEvent actionEvent){
        if(boton_reproduccion.getStyleClass().contains("boton-barra-reproduccion-pausa")){
            boton_reproduccion.getStyleClass().clear();
            boton_reproduccion.getStyleClass().add("boton-barra-reproduccion-play");
        }
        if(boton_reproduccion.getStyle().contains("boton-barra-reproduccion-play")){
            boton_reproduccion.getStyleClass().clear();
            boton_reproduccion.getStyleClass().add("boton-barra-reproduccion-pausa");
        }
    }

    public String sacarArtistas(int id){
        for (Album a : all_albums){
            if (a.getId() == id){
                for (Artista ar :listaA){
                    if (ar.getId() == a.getArtista_id()){
                        return ar.getNombre();
                    }
                }
            }
        }
        return null;
    }

    public void verAlbums(MouseEvent mouseEvent) {
        album_search.getChildren().removeIf(node -> node instanceof Pane);
        cambioPaneles();
        album_search.setVisible(true);
        int escaladoX = 47;
        int escaladoY = 276;
        for (Album a : all_albums){
            Pane panel = new Pane();
            ImageView foto = new ImageView();
            Label titulo = new Label();
            Label artista = new Label();
            panel.getStyleClass().add("albumes");
            foto.getStyleClass().add("fotos-albumes");
            titulo.getStyleClass().add("artista-titulo-albumes");
            artista.getStyleClass().add("artista-titulo-albumes");
            titulo.setText(a.getTitulo());
            artista.setText(sacarArtistas(a.getId()));
            panel.setLayoutX(escaladoX);
            panel.setLayoutY(escaladoY);
            panel.setId(String.valueOf(a.getId()));
            panel.setOnMouseClicked( event -> {
                selected_album.getChildren().removeIf(node -> node instanceof Pane);
                cambioPaneles();
                selected_album.setVisible(true);
                selected_album.setId(String.valueOf(a.getId()));
                if (album_seguidos.contains(a)){
                    boton_seguir_album.setVisible(false);
                    boton_noseguir_album.setVisible(true);
                }
                else {
                    boton_seguir_album.setVisible(true);
                    boton_noseguir_album.setVisible(false);
                }
                titulo_album.setText(titulo.getText());
                artista_album.setText(artista.getText());
                fecha_album.setText("Año : "+a.getAño());
                int layY = 424;
                for (Cancion c : all_songs) {
                    if (String.valueOf(c.getAlbum_id()).equals(panel.getId())){
                        Pane pane = new Pane();
                        Label titulo_c = new Label();
                        ImageView foto_cancion = new ImageView();
                        Separator separator = new Separator();
                        pane.getStyleClass().add("albumes-canciones");
                        titulo_c.getStyleClass().add("titulos-canciones");
                        foto_cancion.getStyleClass().add("imagenes-canciones");
                        separator.getStyleClass().add("separadores");
                        separator.setLayoutY(80);
                        pane.setLayoutX(62);
                        pane.setLayoutY(layY);
                        pane.setId(String.valueOf(c.getId()));
                        foto_cancion.setLayoutX(24);
                        foto_cancion.setLayoutY(10);
                        foto_cancion.setFitWidth(74);
                        foto_cancion.setFitHeight(66);
                        titulo_c.setLayoutX(208);
                        titulo_c.setLayoutY(30);
                        titulo_c.setText(c.getTitulo());
                        pane.setOnMouseClicked(event1 -> {
                            escuchado_recientemente_c.add(c);
                            barra_rep.setVisible(true);
                            barra_rep.setId(String.valueOf(c.getId()));
                            for (Playlist play : lista_favoritas){
                                if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                                    icono_megusta_cancion.setVisible(true);
                                    icono_nomegusta_cancion.setVisible(false);
                                    break;
                                }
                                else{
                                    icono_megusta_cancion.setVisible(false);
                                    icono_nomegusta_cancion.setVisible(true);
                                    break;
                                }
                            }
                            vbox_izquierda.setPrefHeight(731);
                            scroll_pane.setPrefHeight(658);
                            titulo_reproduciendo.setText(c.getTitulo());
                            for (Album alb : all_albums){
                                if (c.getAlbum_id() == alb.getId()){
                                    for (Artista ar : listaA){
                                        if (alb.getArtista_id() == ar.getId()){
                                            artista_reproduciendo.setText(ar.getNombre());
                                        }
                                    }
                                }
                            }
                            imagen_reproduciendo.setImage(foto_cancion.getImage());
                        });
                        pane.getChildren().addAll(titulo_c,foto_cancion,separator);
                        selected_album.getChildren().add(pane);
                        layY+=80;
                    }
                }
                Pane ajuste = new Pane();
                ajuste.setLayoutY(layY+200);
                selected_album.getChildren().add(ajuste);
            });
            foto.setFitWidth(343);
            foto.setFitHeight(350);
            foto.setLayoutX(4);
            foto.setLayoutY(4);
            titulo.setLayoutX(14);
            titulo.setLayoutY(361);
            artista.setLayoutX(14);
            artista.setLayoutY(398);
            panel.getChildren().addAll(foto,titulo,artista);
            album_search.getChildren().add(panel);
            if (escaladoX < 873) {
                escaladoX += 413;
            }
            else if (escaladoX == 873){
                escaladoX=47;
                escaladoY+=500;
            }
        }
        Pane pane_a = new Pane();
        pane_a.setLayoutY(escaladoY+600);
        album_search.getChildren().add(pane_a);
    }

    public void buscarAlbum(KeyEvent keyEvent) {
        album_search.getChildren().removeIf(node -> node instanceof Pane);
        int escaladoX = 47;
        int escaladoY = 276;
        for (Album a : all_albums){
            if (a.getTitulo().toLowerCase(Locale.ROOT).contains(buscador_albumes.getText().toLowerCase(Locale.ROOT))){
                Pane panel = new Pane();
                ImageView foto = new ImageView();
                Label titulo = new Label();
                Label artista = new Label();
                panel.getStyleClass().add("albumes");
                foto.getStyleClass().add("fotos-albumes");
                titulo.getStyleClass().add("artista-titulo-albumes");
                artista.getStyleClass().add("artista-titulo-albumes");
                titulo.setText(a.getTitulo());
                artista.setText(sacarArtistas(a.getId()));
                panel.setLayoutX(escaladoX);
                panel.setLayoutY(escaladoY);
                panel.setId(String.valueOf(a.getId()));
                panel.setOnMouseClicked( event -> {
                    selected_album.getChildren().removeIf(node -> node instanceof Pane);
                    cambioPaneles();
                    selected_album.setVisible(true);
                    selected_album.setId(String.valueOf(a.getId()));
                    if (album_seguidos.contains(a)){
                        boton_seguir_album.setVisible(false);
                        boton_noseguir_album.setVisible(true);
                    }
                    else {
                        boton_seguir_album.setVisible(true);
                        boton_noseguir_album.setVisible(false);
                    }
                    titulo_album.setText(titulo.getText());
                    artista_album.setText(artista.getText());
                    fecha_album.setText("Año : "+a.getAño());
                    int layY = 424;
                    for (Cancion c : all_songs) {
                        if (String.valueOf(c.getAlbum_id()).equals(panel.getId())){
                            Pane pane = new Pane();
                            Label titulo_c = new Label();
                            ImageView foto_cancion = new ImageView();
                            Separator separator = new Separator();
                            pane.getStyleClass().add("albumes-canciones");
                            titulo_c.getStyleClass().add("titulos-canciones");
                            foto_cancion.getStyleClass().add("imagenes-canciones");
                            separator.getStyleClass().add("separadores");
                            separator.setLayoutY(80);
                            pane.setLayoutX(62);
                            pane.setLayoutY(layY);
                            pane.setId(String.valueOf(c.getId()));
                            foto_cancion.setLayoutX(24);
                            foto_cancion.setLayoutY(10);
                            foto_cancion.setFitWidth(74);
                            foto_cancion.setFitHeight(66);
                            titulo_c.setLayoutX(208);
                            titulo_c.setLayoutY(30);
                            titulo_c.setText(c.getTitulo());
                            pane.setOnMouseClicked(event1 -> {
                                escuchado_recientemente_c.add(c);
                                barra_rep.setVisible(true);
                                barra_rep.setId(String.valueOf(c.getId()));
                                for (Playlist play : lista_favoritas){
                                    if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                                        icono_megusta_cancion.setVisible(true);
                                        icono_nomegusta_cancion.setVisible(false);
                                        break;
                                    }
                                    else{
                                        icono_megusta_cancion.setVisible(false);
                                        icono_nomegusta_cancion.setVisible(true);
                                        break;
                                    }
                                }
                                vbox_izquierda.setPrefHeight(731);
                                scroll_pane.setPrefHeight(658);
                                titulo_reproduciendo.setText(c.getTitulo());
                                for (Album alb : all_albums){
                                    if (c.getAlbum_id() == alb.getId()){
                                        for (Artista ar : listaA){
                                            if (alb.getArtista_id() == ar.getId()){
                                                artista_reproduciendo.setText(ar.getNombre());
                                            }
                                        }
                                    }
                                }
                                imagen_reproduciendo.setImage(foto_cancion.getImage());
                            });
                            pane.getChildren().addAll(titulo_c,foto_cancion,separator);
                            selected_album.getChildren().add(pane);
                            layY+=80;
                        }
                    }
                    Pane ajuste = new Pane();
                    ajuste.setLayoutY(layY+200);
                    selected_album.getChildren().add(ajuste);
                });
                foto.setFitWidth(343);
                foto.setFitHeight(350);
                foto.setLayoutX(4);
                foto.setLayoutY(4);
                titulo.setLayoutX(14);
                titulo.setLayoutY(361);
                artista.setLayoutX(14);
                artista.setLayoutY(398);
                panel.getChildren().addAll(foto,titulo,artista);
                album_search.getChildren().add(panel);
                if (escaladoX < 873) {
                    escaladoX += 413;
                }
                else if (escaladoX == 873){
                    escaladoX=47;
                    escaladoY+=500;
                }
            }
            Pane pane_a = new Pane();
            pane_a.setLayoutY(escaladoY+600);
            album_search.getChildren().add(pane_a);
        }
    }

    public void verArtistas(MouseEvent mouseEvent) {
        all_artists.getChildren().removeIf(node -> node instanceof Pane);
        cambioPaneles();
        all_artists.setVisible(true);
        int layX = 50 ;int layY = 271;
        for (Artista a : listaA){
            Pane pane = new Pane();
            Circle foto = new Circle();
            Label nombre = new Label();
            pane.getStyleClass().add("artistas");
            foto.getStyleClass().add("foto-artistas");
            nombre.getStyleClass().add("artista-titulo-albumes");
            nombre.setText(a.getNombre());
            pane.setLayoutX(layX);
            pane.setLayoutY(layY);
            pane.setId(String.valueOf(a.getId()));
            pane.setOnMouseClicked(event -> {
                selected_artist.getChildren().removeIf(node -> node instanceof Pane);
                cambioPaneles();
                selected_artist.setVisible(true);
                selected_artist.setId(String.valueOf(a.getId()));
                if (artistas_seguidos.contains(a)){
                    boton_seguir_artista.setVisible(false);
                    boton_noseguir_artista.setVisible(true);
                }
                else{
                    boton_seguir_artista.setVisible(true);
                    boton_noseguir_artista.setVisible(false);
                }
                nombre_artista.setText(a.getNombre());
                int escaladoY = 424;
                for (Album al :all_albums){
                    if (a.getId() == al.getArtista_id()){
                        for (Cancion ca : all_songs){
                            if (al.getId() == ca.getAlbum_id()){
                                Pane pane_c = new Pane();
                                Separator sep = new Separator();
                                ImageView foto_c = new ImageView();
                                Label titulo = new Label();
                                Label album = new Label();
                                pane_c.getStyleClass().add("canciones-albums-artistas");
                                foto_c.getStyleClass().add("imagenes-canciones");
                                titulo.getStyleClass().add("titulos-canciones");
                                album.getStyleClass().add("titulos-canciones");
                                sep.getStyleClass().add("separadores");
                                sep.setLayoutY(103);
                                pane_c.setLayoutX(68);
                                pane_c.setLayoutY(escaladoY);
                                foto_c.setLayoutX(14);
                                foto_c.setLayoutY(7);
                                foto_c.setFitWidth(94);
                                foto_c.setFitHeight(90);
                                titulo.setLayoutX(195);
                                titulo.setLayoutY(41);
                                titulo.setText(ca.getTitulo());
                                album.setLayoutX(760);
                                album.setLayoutY(41);
                                album.setText(al.getTitulo());
                                pane_c.setOnMouseClicked(event1 -> {
                                    escuchado_recientemente_c.add(ca);
                                    barra_rep.setVisible(true);
                                    barra_rep.setId(String.valueOf(ca.getId()));
                                    for (Playlist play : lista_favoritas){
                                        if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(ca)){
                                            icono_megusta_cancion.setVisible(true);
                                            icono_nomegusta_cancion.setVisible(false);
                                            break;
                                        }
                                        else{
                                            icono_megusta_cancion.setVisible(false);
                                            icono_nomegusta_cancion.setVisible(true);
                                            break;
                                        }
                                    }
                                    vbox_izquierda.setPrefHeight(731);
                                    scroll_pane.setPrefHeight(658);
                                    titulo_reproduciendo.setText(ca.getTitulo());
                                    for (Album alb : all_albums){
                                        if (ca.getAlbum_id() == alb.getId()){
                                            for (Artista ar : listaA){
                                                if (alb.getArtista_id() == ar.getId()){
                                                    artista_reproduciendo.setText(ar.getNombre());
                                                }
                                            }
                                        }
                                    }
                                    imagen_reproduciendo.setImage(foto_c.getImage());
                                });
                                pane_c.getChildren().addAll(foto_c,titulo,album,sep);
                                selected_artist.getChildren().add(pane_c);
                                escaladoY+=113;
                            }
                        }
                    }
                }
                Pane espaciado = new Pane();
                espaciado.setLayoutY(escaladoY+200);
                selected_artist.getChildren().add(espaciado);
            });
            foto.setRadius(120);
            foto.setLayoutX(150);
            foto.setLayoutY(146);
            nombre.layoutXProperty().bind(pane.widthProperty().subtract(nombre.widthProperty()).divide(2));
            nombre.setLayoutY(316);
            pane.getChildren().addAll(foto,nombre);
            all_artists.getChildren().add(pane);
            if (layX < 930){
                layX+=440;
            }
            else if (layX == 930){
                layX=50;
                layY+=400;
            }
        }
    }

    public void buscarArtistas(KeyEvent keyEvent) {
        all_artists.getChildren().removeIf(node -> node instanceof Pane);
        int layX = 50 ;int layY = 271;
        for (Artista a : listaA){
            if (a.getNombre().toLowerCase(Locale.ROOT).contains(buscar_artistas.getText().toLowerCase(Locale.ROOT))){
                Pane pane = new Pane();
                Circle foto = new Circle();
                Label nombre = new Label();
                pane.getStyleClass().add("artistas");
                foto.getStyleClass().add("foto-artistas");
                nombre.getStyleClass().add("artista-titulo-albumes");
                nombre.setText(a.getNombre());
                pane.setLayoutX(layX);
                pane.setLayoutY(layY);
                pane.setId(String.valueOf(a.getId()));
                pane.setOnMouseClicked(event -> {
                    selected_artist.getChildren().removeIf(node -> node instanceof Pane);
                    cambioPaneles();
                    selected_artist.setVisible(true);
                    selected_artist.setId(String.valueOf(a.getId()));
                    if (artistas_seguidos.contains(a)){
                        boton_seguir_artista.setVisible(false);
                        boton_noseguir_artista.setVisible(true);
                    }
                    else{
                        boton_seguir_artista.setVisible(true);
                        boton_noseguir_artista.setVisible(false);
                    }
                    nombre_artista.setText(a.getNombre());
                    int escaladoY = 424;
                    for (Album al :all_albums){
                        if (a.getId() == al.getArtista_id()){
                            for (Cancion ca : all_songs){
                                if (al.getId() == ca.getAlbum_id()){
                                    Pane pane_c = new Pane();
                                    Separator sep = new Separator();
                                    ImageView foto_c = new ImageView();
                                    Label titulo = new Label();
                                    Label album = new Label();
                                    pane_c.getStyleClass().add("canciones-albums-artistas");
                                    foto_c.getStyleClass().add("imagenes-canciones");
                                    titulo.getStyleClass().add("titulos-canciones");
                                    album.getStyleClass().add("titulos-canciones");
                                    sep.getStyleClass().add("separadores");
                                    sep.setLayoutY(103);
                                    pane_c.setLayoutX(68);
                                    pane_c.setLayoutY(escaladoY);
                                    foto_c.setLayoutX(14);
                                    foto_c.setLayoutY(7);
                                    foto_c.setFitWidth(94);
                                    foto_c.setFitHeight(90);
                                    titulo.setLayoutX(195);
                                    titulo.setLayoutY(41);
                                    titulo.setText(ca.getTitulo());
                                    album.setLayoutX(760);
                                    album.setLayoutY(41);
                                    album.setText(al.getTitulo());
                                    pane_c.setOnMouseClicked(event1 -> {
                                        escuchado_recientemente_c.add(ca);
                                        barra_rep.setVisible(true);
                                        barra_rep.setId(String.valueOf(ca.getId()));
                                        for (Playlist play : lista_favoritas){
                                            if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(ca)){
                                                icono_megusta_cancion.setVisible(true);
                                                icono_nomegusta_cancion.setVisible(false);
                                                break;
                                            }
                                            else{
                                                icono_megusta_cancion.setVisible(false);
                                                icono_nomegusta_cancion.setVisible(true);
                                                break;
                                            }
                                        }
                                        vbox_izquierda.setPrefHeight(731);
                                        scroll_pane.setPrefHeight(658);
                                        titulo_reproduciendo.setText(ca.getTitulo());
                                        for (Album alb : all_albums){
                                            if (ca.getAlbum_id() == alb.getId()){
                                                for (Artista ar : listaA){
                                                    if (alb.getArtista_id() == ar.getId()){
                                                        artista_reproduciendo.setText(ar.getNombre());
                                                    }
                                                }
                                            }
                                        }
                                        imagen_reproduciendo.setImage(foto_c.getImage());
                                    });
                                    pane_c.getChildren().addAll(foto_c,titulo,album,sep);
                                    selected_artist.getChildren().add(pane_c);
                                    escaladoY+=113;
                                }
                            }
                        }
                    }
                    Pane espaciado = new Pane();
                    espaciado.setLayoutY(escaladoY+200);
                    selected_artist.getChildren().add(espaciado);
                });
                foto.setRadius(120);
                foto.setLayoutX(150);
                foto.setLayoutY(146);
                nombre.layoutXProperty().bind(pane.widthProperty().subtract(nombre.widthProperty()).divide(2));
                nombre.setLayoutY(316);
                pane.getChildren().addAll(foto,nombre);
                all_artists.getChildren().add(pane);
                if (layX < 930){
                    layX+=440;
                }
                else if (layX == 930){
                    layX=50;
                    layY+=400;
                }
            }
        }
    }

    public void verPodcasts(MouseEvent mouseEvent) {
        search_podcast.getChildren().removeIf(node -> node instanceof Pane);
        cambioPaneles();
        search_podcast.setVisible(true);
        int layX = 51 ; int layY = 263 ;
        for (Podcasts p : all_podcasts){
            Pane pane = new Pane();
            ImageView foto = new ImageView();
            Label titulo = new Label();
            Text año = new Text();
            pane.getStyleClass().add("podcasts");
            foto.getStyleClass().add("fotos-podcasts");
            titulo.getStyleClass().add("titulos-podcasts");
            año.getStyleClass().add("descripcion-podcasts");
            pane.setLayoutX(layX);
            pane.setLayoutY(layY);
            pane.setId(String.valueOf(p.getId()));
            pane.setOnMouseClicked(event -> {
                selected_podcast.getChildren().removeIf(node -> node instanceof Pane);
                cambioPaneles();
                selected_podcast.setVisible(true);
                selected_podcast.setId(String.valueOf(p.getId()));
                if (podcasts_seguidos.contains(p)){
                    boton_seguir_podcast.setVisible(false);
                    boton_noseguir_podcast.setVisible(true);
                }
                else {
                    boton_seguir_podcast.setVisible(true);
                    boton_noseguir_podcast.setVisible(false);
                }
                titulo_podcast.setText(p.getTitulo());
                descripcion_pod.setText(p.getDescripción());
                int escaladoY = 427;
                for (Capitulo c : all_chapters){
                    if (String.valueOf(c.getPodcast_id()).equals(pane.getId())){
                        Pane p_cap = new Pane();
                        Label titulo_cap = new Label();
                        Label descripcion_cap = new Label();
                        Label fecha_cap = new Label();
                        Separator separator = new Separator();
                        separator.getStyleClass().add("separadores");
                        p_cap.getStyleClass().add("capitulos");
                        titulo_cap.getStyleClass().add("titulos-capitulos");
                        descripcion_cap.getStyleClass().add("descripcion-capitulos");
                        fecha_cap.getStyleClass().add("app-subtitle-labels");
                        p_cap.setLayoutX(62);
                        p_cap.setLayoutY(escaladoY);
                        separator.setLayoutY(161);
                        titulo_cap.setLayoutX(43);
                        titulo_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(titulo_cap.heightProperty()).divide(2));
                        titulo_cap.setWrapText(true);
                        titulo_cap.setText(c.getTitulo());
                        descripcion_cap.setLayoutX(309);
                        descripcion_cap.setPrefHeight(200);
                        descripcion_cap.setWrapText(true);
                        descripcion_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(descripcion_cap.heightProperty()).divide(2));
                        descripcion_cap.setText(c.getDescripcion());
                        fecha_cap.setLayoutX(1056);
                        fecha_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(fecha_cap.heightProperty()).divide(2));
                        fecha_cap.setText(c.getFecha().toString());
                        p_cap.setOnMouseClicked(event1 -> {
                            escuchado_recientemente_p.add(c);
                            barra_rep.setVisible(true);
                            icono_megusta_cancion.setVisible(false);
                            icono_nomegusta_cancion.setVisible(false);
                            vbox_izquierda.setPrefHeight(731);
                            scroll_pane.setPrefHeight(658);
                            titulo_reproduciendo.setText(c.getTitulo());
                            artista_reproduciendo.setText(" ");
                            imagen_reproduciendo.setImage(foto.getImage());
                        });
                        p_cap.getChildren().addAll(titulo_cap,descripcion_cap,fecha_cap,separator);
                        selected_podcast.getChildren().add(p_cap);
                        escaladoY+=161;
                    }
                }
                Pane espacio_abajo = new Pane();
                espacio_abajo.setLayoutY(escaladoY+200);
                selected_podcast.getChildren().add(espacio_abajo);
            });
            foto.setLayoutX(14);
            foto.setLayoutY(14);
            foto.setFitWidth(192);
            foto.setFitHeight(196);
            titulo.setLayoutX(222);
            titulo.setLayoutY(14);
            titulo.setWrapText(true);
            titulo.setText(p.getTitulo());
            año.setLayoutX(220);
            año.setLayoutY(116);
            año.setText("Año : "+String.valueOf(p.getAño()));
            pane.getChildren().addAll(foto,titulo,año);
            search_podcast.getChildren().add(pane);
            if (layX < 664){
                layX+=613;
            }
            else if (layX == 664){
                layX=51;
                layY+=290;
            }
        }
        Pane rebasar = new Pane();
        rebasar.setLayoutY(layY+300);
        search_podcast.getChildren().add(rebasar);
    }

    public void buscar_podcast(KeyEvent keyEvent) {
        search_podcast.getChildren().removeIf(node -> node instanceof Pane);
        cambioPaneles();
        search_podcast.setVisible(true);
        int layX = 51 ; int layY = 263 ;
        for (Podcasts p : all_podcasts){
            if (p.getTitulo().toLowerCase(Locale.ROOT).contains(buscar_pod.getText().toLowerCase(Locale.ROOT))){
                Pane pane = new Pane();
                ImageView foto = new ImageView();
                Label titulo = new Label();
                Text año = new Text();
                pane.getStyleClass().add("podcasts");
                foto.getStyleClass().add("fotos-podcasts");
                titulo.getStyleClass().add("titulos-podcasts");
                año.getStyleClass().add("descripcion-podcasts");
                pane.setLayoutX(layX);
                pane.setLayoutY(layY);
                pane.setId(String.valueOf(p.getId()));
                pane.setOnMouseClicked(event -> {
                    selected_podcast.getChildren().removeIf(node -> node instanceof Pane);
                    cambioPaneles();
                    selected_podcast.setVisible(true);
                    selected_podcast.setId(String.valueOf(p.getId()));
                    if (podcasts_seguidos.contains(p)){
                        boton_seguir_podcast.setVisible(false);
                        boton_noseguir_podcast.setVisible(true);
                    }
                    else {
                        boton_seguir_podcast.setVisible(true);
                        boton_noseguir_podcast.setVisible(false);
                    }
                    titulo_podcast.setText(p.getTitulo());
                    descripcion_pod.setText(p.getDescripción());
                    int escaladoY = 427;
                    for (Capitulo c : all_chapters){
                        if (String.valueOf(c.getPodcast_id()).equals(pane.getId())){
                            Pane p_cap = new Pane();
                            Label titulo_cap = new Label();
                            Label descripcion_cap = new Label();
                            Label fecha_cap = new Label();
                            Separator separator = new Separator();
                            separator.getStyleClass().add("separadores");
                            p_cap.getStyleClass().add("capitulos");
                            titulo_cap.getStyleClass().add("titulos-capitulos");
                            descripcion_cap.getStyleClass().add("descripcion-capitulos");
                            fecha_cap.getStyleClass().add("app-subtitle-labels");
                            p_cap.setLayoutX(62);
                            p_cap.setLayoutY(escaladoY);
                            separator.setLayoutY(161);
                            titulo_cap.setLayoutX(43);
                            titulo_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(titulo_cap.heightProperty()).divide(2));
                            titulo_cap.setWrapText(true);
                            titulo_cap.setText(c.getTitulo());
                            descripcion_cap.setLayoutX(309);
                            descripcion_cap.setPrefHeight(200);
                            descripcion_cap.setWrapText(true);
                            descripcion_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(descripcion_cap.heightProperty()).divide(2));
                            descripcion_cap.setText(c.getDescripcion());
                            fecha_cap.setLayoutX(1056);
                            fecha_cap.layoutYProperty().bind(p_cap.heightProperty().subtract(fecha_cap.heightProperty()).divide(2));
                            fecha_cap.setText(c.getFecha().toString());
                            p_cap.setOnMouseClicked(event1 -> {
                                escuchado_recientemente_p.add(c);
                                barra_rep.setVisible(true);
                                icono_nomegusta_cancion.setVisible(false);
                                icono_megusta_cancion.setVisible(false);
                                vbox_izquierda.setPrefHeight(731);
                                scroll_pane.setPrefHeight(658);
                                titulo_reproduciendo.setText(c.getTitulo());
                                artista_reproduciendo.setText(" ");
                                imagen_reproduciendo.setImage(foto.getImage());
                            });
                            p_cap.getChildren().addAll(titulo_cap,descripcion_cap,fecha_cap,separator);
                            selected_podcast.getChildren().add(p_cap);
                            escaladoY+=161;
                        }
                    }
                    Pane espacio_abajo = new Pane();
                    espacio_abajo.setLayoutY(escaladoY+200);
                    selected_podcast.getChildren().add(espacio_abajo);
                });
                foto.setLayoutX(14);
                foto.setLayoutY(14);
                foto.setFitWidth(192);
                foto.setFitHeight(196);
                titulo.setLayoutX(222);
                titulo.setLayoutY(14);
                titulo.setWrapText(true);
                titulo.setText(p.getTitulo());
                año.setLayoutX(220);
                año.setLayoutY(116);
                año.setText("Año : "+String.valueOf(p.getAño()));
                pane.getChildren().addAll(foto,titulo,año);
                search_podcast.getChildren().add(pane);
                if (layX < 664){
                    layX+=613;
                }
                else if (layX == 664){
                    layX=51;
                    layY+=290;
                }
            }
        }
        Pane rebasar = new Pane();
        rebasar.setLayoutY(layY+300);
        search_podcast.getChildren().add(rebasar);
    }

    public void crearPlaylist(){
        if (new_playlist_id.getText().isBlank()){
            alert_playlist.setVisible(true);
            new Shake(alert_playlist).play();
        }
        else{
            String titulo_p = new_playlist_id.getText();
            crearNuevaPlaylist(actual.getId(), titulo_p);
            cambioPaneles();
            tus_playlists.setVisible(true);
            alert_playlist.setVisible(false);
            tusPlaylists();
        }
    }

    public void pasarPremium(ActionEvent actionEvent) {
        cambioPaneles();
        premium_ventana.setVisible(true);
    }

    public void pagoTarjeta(MouseEvent mouseEvent) {
        cambioPaneles();
        tarjeta_ventana.setVisible(true);
    }

    public void pagoPaypal(MouseEvent mouseEvent){
        cambioPaneles();
        paypal_ventana.setVisible(true);
    }

    public void revisarPago(ActionEvent actionEvent) {
        boolean validarT = false;
        if (num_tarjeta.getText().isBlank() || mes_caducidad.getText().isBlank() || año_caducidad.getText().isBlank() || cod_seguridad.getText().isBlank()){
            alert_tarjeta_incorrect.setVisible(false);
            alert_tarjeta_rellenar.setVisible(true);
            new Shake(alert_tarjeta_rellenar).play();
        }
        else{
            for (Tarjeta t : lista_tarjetas) {
                if (num_tarjeta.getText().equals(t.getNum_tarjeta())
                        && mes_caducidad.getText().equals(String.valueOf(t.getMes_caducidad()))
                        && año_caducidad.getText().equals(String.valueOf(t.getAño_caducidad()))
                        && cod_seguridad.getText().equals(String.valueOf(t.getCod_seguridad()))) {
                    validarT = true;
                    insertarUsuarioaPremium(actual.getId(),t.getId());
                    cambioPaneles();
                    inicio_app.setVisible(true);
                    hazte_premium.setVisible(false);
                }
            }
            if (validarT == false){
                alert_tarjeta_rellenar.setVisible(false);
                alert_tarjeta_incorrect.setVisible(true);
                new Shake(alert_tarjeta_incorrect).play();
            }
        }
    }


    public void revisarUsuarioPaypal(ActionEvent actionEvent) {
        boolean validarT = false;
        if (usuario_paypal.getText().isBlank()){
            alert_usuarioPaypal_incorrect.setVisible(false);
            alert_usuarioPaypal_vacio.setVisible(true);
            new Shake(alert_usuarioPaypal_vacio).play();
        }
        else {
            for (Paypal p : lista_paypal){
                if (usuario_paypal.getText().equals(p.getUsuario())){
                    validarT=true;
                    insertarUsuarioaPremium(actual.getId(),p.getId());
                    cambioPaneles();
                    inicio_app.setVisible(true);
                    hazte_premium.setVisible(false);
                }
            }
            if (validarT == false){
                alert_usuarioPaypal_vacio.setVisible(false);
                alert_usuarioPaypal_incorrect.setVisible(true);
                new Shake(alert_usuarioPaypal_incorrect).play();
            }
        }
    }

    public void pantallaRegistro(MouseEvent mouseEvent) {
        panel1.setVisible(false);
        username_text.clear();
        passwrd_text.clear();
        alert_incompleted.setVisible(false);
        alert_incorrect.setVisible(false);
        panel_registro.setVisible(true);
        new FadeIn(panel_registro).play();
    }

    public void registroNuevoUsuario(ActionEvent actionEvent) {
        boolean validarRegistro=false;
        if (registro_username.getText().isBlank()
                || registro_email.getText().isBlank()
                || registro_contraseña.getText().isBlank()
                || registro_cp.getText().isBlank()
                || fecha_nacimiento.getValue() == null
                || combo_sexo.getSelectionModel().isEmpty()){
            alert_correoAsociado.setVisible(false);
            alert_usuarioExistente.setVisible(false);
            alert_registroVacío.setVisible(true);
            new Shake(alert_registroVacío).play();
        }
        else {
            validarRegistro=true;
            for (Usuario u : usuarios_premium){
                if (registro_username.getText().equals(u.getUsername())){
                    validarRegistro=false;
                    alert_registroVacío.setVisible(false);
                    alert_correoAsociado.setVisible(false);
                    alert_usuarioExistente.setVisible(true);
                    new Shake(alert_usuarioExistente).play();
                    break;
                }
                else if (registro_email.getText().equals(u.getEmail())){
                    validarRegistro=false;
                    alert_registroVacío.setVisible(false);
                    alert_usuarioExistente.setVisible(false);
                    alert_correoAsociado.setVisible(true);
                    new Shake (alert_correoAsociado).play();
                    break;
                }
            }
            for (Usuario us : usuarios_free){
                if (registro_username.getText().equals(us.getUsername())){
                    validarRegistro=false;
                    alert_registroVacío.setVisible(false);
                    alert_correoAsociado.setVisible(false);
                    alert_usuarioExistente.setVisible(true);
                    new Shake(alert_usuarioExistente).play();
                    break;
                }
                else if (registro_email.getText().equals(us.getEmail())){
                    validarRegistro=false;
                    alert_registroVacío.setVisible(false);
                    alert_usuarioExistente.setVisible(false);
                    alert_correoAsociado.setVisible(true);
                    new Shake (alert_correoAsociado).play();
                    break;
                }
            }
            if (validarRegistro){
                registrarNuevoUsuario(registro_username.getText()
                        ,registro_contraseña.getText()
                        ,registro_email.getText()
                        ,combo_sexo.getValue()
                        ,fecha_nacimiento.getValue()
                        ,registro_país.getText()
                        ,registro_cp.getText());
                panel_registro.setVisible(false);
                alert_registroVacío.setVisible(false);
                alert_usuarioExistente.setVisible(false);
                alert_correoAsociado.setVisible(false);
                registro_username.clear();
                registro_contraseña.clear();
                registro_email.clear();
                registro_cp.clear();
                registro_país.clear();
                fecha_nacimiento.setValue(null);
                combo_sexo.setValue(null);
                panel1.setVisible(true);
                new FadeIn(panel1).play();
            }
        }
    }

    public void cambioInicioSesion(ActionEvent actionEvent) {
        panel_registro.setVisible(false);
        alert_registroVacío.setVisible(false);
        alert_usuarioExistente.setVisible(false);
        alert_correoAsociado.setVisible(false);
        registro_username.clear();
        registro_contraseña.clear();
        registro_email.clear();
        registro_cp.clear();
        registro_país.clear();
        fecha_nacimiento.setValue(null);
        combo_sexo.setValue(null);
        panel1.setVisible(true);
        new FadeIn(panel1).play();
    }

    public void seguirAlbum(ActionEvent actionEvent) {
        boton_seguir_album.setVisible(false);
        boton_noseguir_album.setVisible(true);
        new BounceIn(boton_noseguir_album).play();
        usuarioSigueAlbum(actual.getId(),Integer.parseInt(selected_album.getId()));
        albumesSeguidos(actual.getId());
    }

    public void noSeguirAlbum(ActionEvent actionEvent) {
        boton_noseguir_album.setVisible(false);
        boton_seguir_album.setVisible(true);
        new BounceIn(boton_seguir_album).play();
        usuarioNoSigueAlbum(actual.getId(),Integer.parseInt(selected_album.getId()));
        albumesSeguidos(actual.getId());
    }

    public void seguirArtista(ActionEvent actionEvent) {
        boton_seguir_artista.setVisible(false);
        boton_noseguir_artista.setVisible(true);
        new BounceIn(boton_noseguir_artista).play();
        usuarioSigueArtista(actual.getId(),Integer.parseInt(selected_artist.getId()));
    }

    public void noSeguirArtista(ActionEvent actionEvent) {
        boton_noseguir_artista.setVisible(false);
        boton_seguir_artista.setVisible(true);
        new BounceIn(boton_seguir_artista).play();
        usuarioNoSigueArtista(actual.getId(),Integer.parseInt(selected_artist.getId()));
    }

    public void seguirPodcast(ActionEvent actionEvent) {
        boton_seguir_podcast.setVisible(false);
        boton_noseguir_podcast.setVisible(true);
        new BounceIn(boton_noseguir_podcast).play();
        usuarioSiguePodcast(actual.getId(),Integer.parseInt(selected_podcast.getId()));
    }

    public void noSeguirPodcast(ActionEvent actionEvent) {
        boton_noseguir_podcast.setVisible(false);
        boton_seguir_podcast.setVisible(true);
        new BounceIn(boton_seguir_podcast).play();
        usuarioNoSiguePodcast(actual.getId(),Integer.parseInt(selected_podcast.getId()));
    }

    public void añadirCancion(ActionEvent actionEvent) {
        ventana_anyadir_cancion.getChildren().removeIf(node -> node instanceof Pane);
        cambioPaneles();
        Playlist p_actual = null;
        for (Playlist p : playlists_propias){
            if (playlist_id.getId().equals(String.valueOf(p.getId()))){
                p_actual = p;
                break;
            }
        }
        ventana_anyadir_cancion.setVisible(true);
        int layX = 62; int layY = 140;
        for (Cancion c : all_songs){
            if (!p_actual.getCanciones().contains(c)){
                Pane panel = new Pane();
                ImageView foto_c = new ImageView();
                Label titulo_c = new Label();
                Label artista_c = new Label();
                Button anyadir_c = new Button();
                panel.getStyleClass().add("canciones-anyadir");
                foto_c.getStyleClass().add("imagenes-canciones");
                titulo_c.getStyleClass().add("artista-titulo-albumes");
                artista_c.getStyleClass().add("artista-titulo-albumes");
                anyadir_c.getStyleClass().add("botones-seguir");
                panel.setLayoutX(layX);
                panel.setLayoutY(layY);
                panel.setId(String.valueOf(c.getId()));
                foto_c.setLayoutX(6);
                foto_c.setLayoutY(6);
                foto_c.setFitWidth(70);
                foto_c.setFitHeight(70);
                titulo_c.setLayoutX(90);
                titulo_c.setLayoutY(12);
                titulo_c.setText(c.getTitulo());
                artista_c.setLayoutX(90);
                artista_c.setLayoutY(47);
                for (Album a : all_albums){
                    if (c.getAlbum_id() == a.getId()){
                        for (Artista ar : listaA){
                            if (a.getArtista_id() == ar.getId()){
                                artista_c.setText(ar.getNombre());
                            }
                        }
                    }
                }
                anyadir_c.setLayoutX(382);
                anyadir_c.setLayoutY(22);
                anyadir_c.setPrefWidth(87);
                anyadir_c.setPrefHeight(39);
                anyadir_c.setText("Añadir");
                anyadir_c.setOnAction(event -> {
                    anyadirCancionPlaylist(Integer.parseInt(playlist_id.getId()),c.getId(),actual.getId());
                    cambioPaneles();
                    tusPlaylists();
                    tus_playlists.setVisible(true);
                });
                panel.setOnMouseClicked(event -> {
                    escuchado_recientemente_c.add(c);
                    barra_rep.setVisible(true);
                    barra_rep.setId(String.valueOf(c.getId()));
                    for (Playlist play : lista_favoritas){
                        if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                            icono_megusta_cancion.setVisible(true);
                            icono_nomegusta_cancion.setVisible(false);
                            break;
                        }
                        else{
                            icono_megusta_cancion.setVisible(false);
                            icono_nomegusta_cancion.setVisible(true);
                            break;
                        }
                    }
                    vbox_izquierda.setPrefHeight(731);
                    scroll_pane.setPrefHeight(658);
                    titulo_reproduciendo.setText(c.getTitulo());
                    for (Album a : all_albums){
                        if (c.getAlbum_id() == a.getId()){
                            for (Artista ar : listaA){
                                if (a.getArtista_id() == ar.getId()){
                                    artista_reproduciendo.setText(ar.getNombre());
                                }
                            }
                        }
                    }
                    imagen_reproduciendo.setImage(foto_c.getImage());
                });
                panel.getChildren().addAll(titulo_c,artista_c,foto_c,anyadir_c);
                ventana_anyadir_cancion.getChildren().add(panel);
                if (layX < 736){
                    layX+=674;
                }
                else if ( layX == 736){
                    layX=62;
                    layY+=86;
                }
            }
        }
        Pane espaciado_abajo = new Pane();
        espaciado_abajo.setLayoutY(layY+400);
        ventana_anyadir_cancion.getChildren().add(espaciado_abajo);
    }

    public void buscarAnyadirCancion(KeyEvent keyEvent) {
        ventana_anyadir_cancion.getChildren().removeIf(node -> node instanceof Pane);
        Playlist p_actual = null;
        for (Playlist p : playlists_propias){
            if (playlist_id.getId().equals(String.valueOf(p.getId()))){
                p_actual = p;
                break;
            }
        }
        int layX = 62; int layY = 140;
        for (Cancion c : all_songs){
            if (!p_actual.getCanciones().contains(c)) {
                if (c.getTitulo().toLowerCase(Locale.ROOT).contains(ventana_anyadir_buscar.getText().toLowerCase(Locale.ROOT))) {
                    Pane panel = new Pane();
                    ImageView foto_c = new ImageView();
                    Label titulo_c = new Label();
                    Label artista_c = new Label();
                    Button anyadir_c = new Button();
                    panel.getStyleClass().add("canciones-anyadir");
                    foto_c.getStyleClass().add("imagenes-canciones");
                    titulo_c.getStyleClass().add("artista-titulo-albumes");
                    artista_c.getStyleClass().add("artista-titulo-albumes");
                    anyadir_c.getStyleClass().add("botones-seguir");
                    panel.setLayoutX(layX);
                    panel.setLayoutY(layY);
                    panel.setId(String.valueOf(c.getId()));
                    foto_c.setLayoutX(6);
                    foto_c.setLayoutY(6);
                    foto_c.setFitWidth(70);
                    foto_c.setFitHeight(70);
                    titulo_c.setLayoutX(90);
                    titulo_c.setLayoutY(12);
                    titulo_c.setText(c.getTitulo());
                    artista_c.setLayoutX(90);
                    artista_c.setLayoutY(47);
                    for (Album a : all_albums){
                        if (c.getAlbum_id() == a.getId()){
                            for (Artista ar : listaA){
                                if (a.getArtista_id() == ar.getId()){
                                    artista_c.setText(ar.getNombre());
                                }
                            }
                        }
                    }
                    anyadir_c.setLayoutX(382);
                    anyadir_c.setLayoutY(22);
                    anyadir_c.setPrefWidth(87);
                    anyadir_c.setPrefHeight(39);
                    anyadir_c.setText("Añadir");
                    anyadir_c.setOnAction(event -> {
                        anyadirCancionPlaylist(Integer.parseInt(playlist_id.getId()), c.getId(), actual.getId());
                        cambioPaneles();
                        tusPlaylists();
                        tus_playlists.setVisible(true);
                    });
                    panel.setOnMouseClicked(event -> {
                        escuchado_recientemente_c.add(c);
                        barra_rep.setVisible(true);
                        barra_rep.setId(String.valueOf(c.getId()));
                        for (Playlist play : lista_favoritas){
                            if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                                icono_megusta_cancion.setVisible(true);
                                icono_nomegusta_cancion.setVisible(false);
                                break;
                            }
                            else{
                                icono_megusta_cancion.setVisible(false);
                                icono_nomegusta_cancion.setVisible(true);
                                break;
                            }
                        }
                        vbox_izquierda.setPrefHeight(731);
                        scroll_pane.setPrefHeight(658);
                        titulo_reproduciendo.setText(c.getTitulo());
                        for (Album a : all_albums){
                            if (c.getAlbum_id() == a.getId()){
                                for (Artista ar : listaA){
                                    if (a.getArtista_id() == ar.getId()){
                                        artista_reproduciendo.setText(ar.getNombre());
                                    }
                                }
                            }
                        }
                        imagen_reproduciendo.setImage(foto_c.getImage());
                    });
                    panel.getChildren().addAll(titulo_c, artista_c, foto_c, anyadir_c);
                    ventana_anyadir_cancion.getChildren().add(panel);
                    if (layX < 736) {
                        layX += 674;
                    } else if (layX == 736) {
                        layX = 62;
                        layY += 86;
                    }
                }
            }
        }
        Pane espaciado_abajo = new Pane();
        espaciado_abajo.setLayoutY(layY+400);
        ventana_anyadir_cancion.getChildren().add(espaciado_abajo);
    }

    public void seguirPlaylist(ActionEvent actionEvent){
        boton_seguir_playlist.setVisible(false);
        boton_noseguir_playlist.setVisible(true);
        new BounceIn(boton_noseguir_playlist).play();
        usuarioSiguePlaylist(actual.getId(),Integer.parseInt(playlist_id.getId()));
    }

    public void noSeguirPlaylist(ActionEvent actionEvent) {
        boton_noseguir_playlist.setVisible(false);
        boton_seguir_playlist.setVisible(true);
        new BounceIn(boton_seguir_playlist).play();
        usuarioNoSiguePlaylist(actual.getId(),Integer.parseInt(playlist_id.getId()));
    }

    public void seguirUsuario(ActionEvent actionEvent) {
        boton_seguir_usuario.setVisible(false);
        boton_noseguir_usuario.setVisible(true);
        new BounceIn(boton_noseguir_usuario).play();
        usuarioSigueUsuario(actual.getId(),Integer.parseInt(nombre_usuario_playlist.getId()));
    }

    public void noSeguirUsuario(ActionEvent actionEvent) {
        boton_noseguir_usuario.setVisible(false);
        boton_seguir_usuario.setVisible(true);
        new BounceIn(boton_seguir_usuario).play();
        usuarioNoSigueUsuario(actual.getId(),Integer.parseInt(nombre_usuario_playlist.getId()));
    }

    public void escuchadoRecientemente(){
        recently_played.getChildren().removeIf(node -> node instanceof Pane);
        int cont1 = 0; int cont2 = 0;
        while(escuchado_recientemente_c.size() > 9){
            escuchado_recientemente_c.remove(cont1);
            cont1++;
        }
        while(escuchado_recientemente_p.size() > 9){
            escuchado_recientemente_p.remove(cont2);
            cont2++;
        }
        escuchado_recientemente_c = new ArrayList<Cancion>(new LinkedHashSet<Cancion>(escuchado_recientemente_c));
        escuchado_recientemente_p = new ArrayList<Capitulo>(new LinkedHashSet<Capitulo>(escuchado_recientemente_p));
        int layY= 223;
        for (Cancion c : escuchado_recientemente_c){
            Pane pane = new Pane();
            Separator separator = new Separator();
            Label titulo = new Label();
            Label album = new Label();
            ImageView foto_c = new ImageView();
            foto_c.getStyleClass().add("imagenes-canciones");
            pane.getStyleClass().add("escuchado_recientemente");
            separator.getStyleClass().add("separadores");
            titulo.getStyleClass().add("artista-titulo-albumes");
            album.getStyleClass().add("artista-titulo-albumes");
            separator.setLayoutY(82);
            pane.setLayoutX(64);
            pane.setLayoutY(layY);
            foto_c.setFitHeight(70);
            foto_c.setFitWidth(70);
            foto_c.setLayoutX(6);
            foto_c.setLayoutY(6);
            titulo.setLayoutX(100);
            titulo.setLayoutY(31);
            titulo.setPrefWidth(300);
            titulo.setText(c.getTitulo());
            album.setLayoutX(591);
            album.setLayoutY(31);
            for (Album al : all_albums){
                if (c.getAlbum_id() == al.getId()){
                    album.setText(al.getTitulo());
                }
            }
            pane.setOnMouseClicked(event -> {
                barra_rep.setVisible(true);
                for (Playlist play : lista_favoritas){
                    if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                        icono_megusta_cancion.setVisible(true);
                        icono_nomegusta_cancion.setVisible(false);
                        break;
                    }
                    else{
                        icono_megusta_cancion.setVisible(false);
                        icono_nomegusta_cancion.setVisible(true);
                        break;
                    }
                }
                barra_rep.setId(String.valueOf(c.getId()));
                vbox_izquierda.setPrefHeight(731);
                scroll_pane.setPrefHeight(658);
                titulo_reproduciendo.setText(c.getTitulo());
                for (Album a : all_albums){
                    if (c.getAlbum_id() == a.getId()){
                        for (Artista ar : listaA){
                            if (a.getArtista_id() == ar.getId()){
                                artista_reproduciendo.setText(ar.getNombre());
                            }
                        }
                    }
                }
                imagen_reproduciendo.setImage(foto_c.getImage());
            });
            pane.getChildren().addAll(titulo,album,separator,foto_c);
            recently_played.getChildren().add(pane);
            layY += 82;
        }
        for (Capitulo cap : escuchado_recientemente_p){
            Pane pane = new Pane();
            Separator separator = new Separator();
            Label titulo_cap = new Label();
            Label podcast = new Label();
            ImageView foto_c = new ImageView();
            foto_c.getStyleClass().add("fotos-podcasts");
            pane.getStyleClass().add("escuchado_recientemente");
            separator.getStyleClass().add("separadores");
            titulo_cap.getStyleClass().add("artista-titulo-albumes");
            podcast.getStyleClass().add("artista-titulo-albumes");
            separator.setLayoutY(82);
            pane.setLayoutX(64);
            pane.setLayoutY(layY);
            foto_c.setFitHeight(70);
            foto_c.setFitWidth(70);
            foto_c.setLayoutX(6);
            foto_c.setLayoutY(6);
            titulo_cap.setLayoutX(100);
            titulo_cap.setLayoutY(31);
            titulo_cap.setPrefWidth(300);
            titulo_cap.setText(cap.getTitulo());
            podcast.setLayoutX(591);
            podcast.setLayoutY(31);
            for (Podcasts p : all_podcasts){
                if (cap.getPodcast_id() == p.getId()){
                    podcast.setText(p.getTitulo());
                }
            }
            pane.setOnMouseClicked(event1 -> {
                barra_rep.setVisible(true);
                icono_nomegusta_cancion.setVisible(false);
                icono_megusta_cancion.setVisible(false);
                vbox_izquierda.setPrefHeight(731);
                scroll_pane.setPrefHeight(658);
                titulo_reproduciendo.setText(cap.getTitulo());
                artista_reproduciendo.setText(" ");
                imagen_reproduciendo.setImage(foto_c.getImage());
            });
            pane.getChildren().addAll(titulo_cap,podcast,separator,foto_c);
            recently_played.getChildren().add(pane);
            layY += 82;
        }
    }

    public void likedSongs(){
        liked_songs.getChildren().removeIf(node -> node instanceof Pane);
        playlistsFavoritas();
        for (Playlist p : lista_favoritas){
            if (p.getId() == actual.getId()){
                int layY= 223;
                for (Cancion c : p.getCanciones()){
                    Pane pane = new Pane();
                    Separator separator = new Separator();
                    Label titulo = new Label();
                    Label artista = new Label();
                    ImageView foto_c = new ImageView();
                    foto_c.getStyleClass().add("imagenes-canciones");
                    pane.getStyleClass().add("escuchado_recientemente");
                    separator.getStyleClass().add("separadores");
                    titulo.getStyleClass().add("app-subtitle-labels");
                    artista.getStyleClass().add("app-subtitle-labels");
                    separator.setLayoutY(82);
                    pane.setLayoutX(64);
                    pane.setLayoutY(layY);
                    foto_c.setFitHeight(70);
                    foto_c.setFitWidth(70);
                    foto_c.setLayoutX(6);
                    foto_c.setLayoutY(6);
                    titulo.setLayoutX(183);
                    titulo.setLayoutY(39);
                    titulo.setPrefWidth(300);
                    titulo.setText(c.getTitulo());
                    artista.setLayoutX(620);
                    artista.setLayoutY(39);
                    for (Album al : all_albums){
                        if (c.getAlbum_id() == al.getId()){
                            for (Artista ar : listaA){
                                if (ar.getId() == al.getArtista_id()){
                                    artista.setText(ar.getNombre());
                                }
                            }
                        }
                    }
                    pane.setOnMouseClicked(event -> {
                        escuchado_recientemente_c.add(c);
                        barra_rep.setVisible(true);
                        barra_rep.setId(String.valueOf(c.getId()));
                        for (Playlist play : lista_favoritas){
                            if (play.getUsuario_id() == actual.getId() && play.getCanciones().contains(c)){
                                icono_megusta_cancion.setVisible(true);
                                icono_nomegusta_cancion.setVisible(false);
                                break;
                            }
                            else{
                                icono_megusta_cancion.setVisible(false);
                                icono_nomegusta_cancion.setVisible(true);
                                break;
                            }
                        }
                        vbox_izquierda.setPrefHeight(731);
                        scroll_pane.setPrefHeight(658);
                        titulo_reproduciendo.setText(c.getTitulo());
                        for (Album a : all_albums){
                            if (c.getAlbum_id() == a.getId()){
                                for (Artista ar : listaA){
                                    if (a.getArtista_id() == ar.getId()){
                                        artista_reproduciendo.setText(ar.getNombre());
                                    }
                                }
                            }
                        }
                        imagen_reproduciendo.setImage(foto_c.getImage());
                    });
                    pane.getChildren().addAll(titulo,artista,separator,foto_c);
                    liked_songs.getChildren().add(pane);
                    layY += 82;
                }
                Pane espaciado_abajo = new Pane();
                espaciado_abajo.setLayoutY(layY+300);
                liked_songs.getChildren().add(espaciado_abajo);
            }
        }
    }

    public void darLike(MouseEvent mouseEvent) {
        icono_megusta_cancion.setVisible(true);
        icono_nomegusta_cancion.setVisible(false);
        new BounceIn(icono_megusta_cancion).play();
        usuarioGuardaCancion(actual.getId(),Integer.parseInt(barra_rep.getId()));
        playlistsFavoritas();
    }

    public void quitarLike(MouseEvent mouseEvent) {
        icono_nomegusta_cancion.setVisible(true);
        icono_megusta_cancion.setVisible(false);
        new BounceIn(icono_nomegusta_cancion).play();
        usuarioNoGuardaCancion(actual.getId(),Integer.parseInt(barra_rep.getId()));
        playlistsFavoritas();
    }
}
