package spotify.code;

import Clases.*;
import javafx.scene.image.Image;

import java.sql.*;
import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.sql.Date;

public  interface Consultas {

    ArrayList<Cancion> all_songs= new ArrayList<>();

    ArrayList<Album> all_albums=new ArrayList<>();

    ArrayList<Podcasts> all_podcasts=new ArrayList<>();

    ArrayList<Capitulo> all_chapters=new ArrayList<>();

    ArrayList<Playlist> all_playlists=new ArrayList<>();

    ArrayList<Cancion> canciones_fav=new ArrayList<>();

    ArrayList<Favoritas> lista_favoritas=new ArrayList<>();

    ArrayList<Activa> lista_activas=new ArrayList<>();

    ArrayList<Usuario> all_users=new ArrayList<>();

    ArrayList<Artista>listaA= new ArrayList<>();

    ArrayList<Premium>usuarios_premium=new ArrayList<>();

    ArrayList<Free>usuarios_free=new ArrayList<>();

    ArrayList<Patrocinada>lista_patrocinadas = new ArrayList<>();

    ArrayList<Playlist>playlist_seguidas= new ArrayList<>();

    ArrayList<Playlist>playlists_propias= new ArrayList<>();

    ArrayList<Artista>artistas_seguidos= new ArrayList<>();

    ArrayList<Album>album_seguidos= new ArrayList<>();

    ArrayList<Podcasts>podcasts_seguidos=new ArrayList<>();

    ArrayList<Tarjeta>lista_tarjetas= new ArrayList<>();

    ArrayList<Paypal>lista_paypal=new ArrayList<>();

    ArrayList<Usuario>usuarios_seguidos=new ArrayList<>();


    default Connection conexion() throws SQLException {
        Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify","root","dbrootpass");
        return con;
    }

    default void playlistsPatrocinadas(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT p.*,pa.fecha_inicio,pa.fecha_fin FROM playlist p INNER JOIN patrocinada pa ON pa.playlist_id = p.id");
            while (rs.next()){
                int id=rs.getInt("id");
                String titulo=rs.getString("titulo");
                Date fecha=rs.getDate("fecha_creacion");
                int id_u=rs.getInt("usuario_id");
                Date fecha_i=rs.getDate("fecha_inicio");
                Date fecha_f=rs.getDate("fecha_fin");
                Patrocinada p = new Patrocinada(id,id_u,titulo,fecha,fecha_i,fecha_f);
                lista_patrocinadas.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void playlistsFavoritas(){
        try {
            lista_favoritas.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT p.* FROM playlist p INNER JOIN favoritas f ON f.playlist_id = p.id");
            while (rs.next()){
                int id=rs.getInt("id");
                String titulo=rs.getString("titulo");
                Date fecha=rs.getDate("fecha_creacion");
                int id_u=rs.getInt("usuario_id");
                Favoritas f = new Favoritas(id,id_u,titulo,fecha);
                lista_favoritas.add(f);
            }
            ResultSet rs1 = stm.executeQuery("SELECT * FROM guarda_cancion");
            while(rs1.next()) {
                int u_id = rs1.getInt("usuario_id");
                int c_id = rs1.getInt("cancion_id");
                for (Playlist pl :lista_favoritas){
                    for (Cancion ca : all_songs){
                        if (pl.getUsuario_id() == u_id && ca.getId() == c_id){
                            pl.añadirCancion(ca);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void playlistsActivas(){
        try {
            lista_activas.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT p.*,a.es_compartida FROM playlist p INNER JOIN activa a ON a.playlist_id = p.id");
            while (rs.next()){
                int id=rs.getInt("id");
                String titulo=rs.getString("titulo");
                Date fecha=rs.getDate("fecha_creacion");
                int id_u=rs.getInt("usuario_id");
                boolean compartida = rs.getBoolean("es_compartida");
                Activa a = new Activa(id,id_u,titulo,fecha,compartida);
                lista_activas.add(a);
            }
            ResultSet rs1 = stm.executeQuery("SELECT * FROM anyade_cancion_playlist");
            while(rs1.next()){
                int p_id = rs1.getInt("playlist_id");
                int c_id = rs1.getInt("cancion_id");
                for (Playlist pla :lista_activas){
                    for (Cancion can : all_songs){
                        if (pla.getId() == p_id && can.getId() == c_id){
                            pla.añadirCancion(can);
                        }
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void tusPlaylists(int u_id){
        try {
            playlists_propias.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT p.* FROM playlist p INNER JOIN activa a ON a.playlist_id = p.id AND p.usuario_id ='"+u_id+"'");
            while (rs.next()){
                int id=rs.getInt("id");
                for (Playlist p : lista_activas){
                    if (p.getId() == id){
                        playlists_propias.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void playlistSeguidas(int u_id){
        try {
            all_playlists.clear();
            playlist_seguidas.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT p.* FROM playlist p INNER JOIN sigue_playlist sp ON sp.playlist_id = p.id AND sp.usuario_id ='"+u_id+"'");
            all_playlists.addAll(lista_activas);
            all_playlists.addAll(lista_favoritas);
            while (rs.next()){
                int id=rs.getInt("id");
                for (Playlist p : all_playlists){
                    if (p.getId() == id){
                        playlist_seguidas.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void todosAlbums(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM album");
            while (rs.next()){
                int id=rs.getInt("id");
                int año =rs.getInt("anyo");
                String titulo=rs.getString("titulo");
                String imagen = rs.getString("imagen");
                boolean patrocinada = rs.getBoolean("patrocinado");
                Date fecha_i=rs.getDate("fecha_inicio_patrocinio");
                Date fecha_f=rs.getDate("fecha_fin_patrocinio");
                int artista_id=rs.getInt("artista_id");
                Album a = new Album(id,año,titulo,imagen,patrocinada,fecha_i,fecha_f,artista_id);
                all_albums.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void todosArtistas(){
        try{
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM artista");
            while (rs.next()){
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                Artista a = new Artista(id,nombre);
                listaA.add(a);
            }
        }
        catch (SQLException e){

        }
    }

    default void todasCanciones(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM cancion");
            while(rs.next()){
                int id = rs.getInt("id");
                String titulo = rs.getString("titulo");
                int duracion = rs.getInt("duracion");
                int n_reproducciones = rs.getInt("numero_reproducciones");
                int id_album = rs.getInt("album_id");
                Cancion c = new Cancion(id,titulo,duracion,n_reproducciones,id_album);
                all_songs.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void podcastsSeguidos(int u_id){
        try {
            podcasts_seguidos.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT p.* FROM podcast p INNER JOIN podcast_usuario pu ON pu.podcast_id = p.id AND pu.usuario_id="+u_id);
            while(rs.next()){
                int id = rs.getInt("id");
                for (Podcasts p : all_podcasts){
                    if (id == p.getId()){
                        podcasts_seguidos.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void albumesSeguidos(int u_id){
        try {
            album_seguidos.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT a.* FROM album a INNER JOIN sigue_album sa ON sa.album_id = a.id AND sa.usuario_id="+u_id);
            while(rs.next()){
                int id = rs.getInt("id");
                for (Album a : all_albums){
                    if (id == a.getId()){
                        album_seguidos.add(a);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void artistasSeguidos(int u_id){
        try {
            artistas_seguidos.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT a.* FROM artista a INNER JOIN sigue_artista sa ON sa.artista_id = a.id AND sa.usuario_id="+u_id);
            while(rs.next()){
                int id = rs.getInt("id");
                for (Artista a : listaA){
                    if (id == a.getId()){
                        artistas_seguidos.add(a);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void cancionesPlaylist(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM anyade_cancion_playlist");
            while(rs.next()){
                int p_id = rs.getInt("playlist_id");
                int c_id = rs.getInt("cancion_id");
                for (Playlist p :lista_patrocinadas){
                    for (Cancion c : all_songs){
                        if (p.getId() == p_id && c.getId() == c_id){
                            p.añadirCancion(c);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    default void todosPodcasts(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM podcast");
            while(rs.next()){
                int id = rs.getInt("id");
                String titulo = rs.getString("titulo");
                String descripcion = rs.getString("descripcion");
                int año = rs.getInt("anyo");
                Podcasts p = new Podcasts(id,titulo,descripcion,año);
                all_podcasts.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void todosCapitulos(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM capitulo");
            while(rs.next()){
                int id = rs.getInt("id");
                String titulo = rs.getString("titulo");
                String descripcion = rs.getString("descripcion");
                java.sql.Date año = rs.getDate("fecha");
                int p_id = rs.getInt("podcast_id");
                Capitulo c = new Capitulo(id,titulo,descripcion,año,p_id);
                all_chapters.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void cancionesFavoritas(int id){
        canciones_fav.clear();
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT c.* FROM cancion c INNER JOIN anyade_cancion_playlist acp ON acp.cancion_id = c.id INNER JOIN favoritas f ON f.playlist_id = acp.playlist_id INNER JOIN usuario u ON acp.usuario_id = u.id AND u.id="+id);
            while(rs.next()){
                int id_C = rs.getInt("id");
                for (Cancion c : all_songs){
                    if (c.getId() == id_C){
                        canciones_fav.add(c);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuariosPremium(){
        try{
            all_users.clear();
            usuarios_premium.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT u.*,p.fecha_renovación FROM usuario u INNER JOIN premium p ON p.usuario_id=u.id");
            while (rs.next()){
                int ide= rs.getInt("id");
                String nombre= rs.getString("username");
                String pssw = rs.getString("password");
                String mail = rs.getString("email");
                char sex = rs.getString("genero").charAt(0);
                Date d = rs.getDate("fecha_nacimiento");
                String country = rs.getString("pais");
                String CP = rs.getString("codigo_postal");
                Date fecha= rs.getDate("fecha_renovación");
                Premium n = new Premium(ide,nombre,pssw,mail,sex,d,country,CP,fecha);
                usuarios_premium.add(n);
            }
            all_users.addAll(usuarios_premium);
        }
        catch (SQLException e){

        }
    }

    default void usuariosFree(){
        try{
            usuarios_free.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT u.*,f.fecha_revision,f.tiempo_publicidad FROM usuario u INNER JOIN free f ON f.usuario_id=u.id");
            while (rs.next()){
                int ide= rs.getInt("id");
                String nombre= rs.getString("username");
                String pssw = rs.getString("password");
                String mail = rs.getString("email");
                char sex = rs.getString("genero").charAt(0);
                Date d = rs.getDate("fecha_nacimiento");
                String country = rs.getString("pais");
                String CP = rs.getString("codigo_postal");
                Date fecha_rev= rs.getDate("fecha_revision");
                int tiempo_p=rs.getInt("tiempo_publicidad");
                Free n = new Free(ide,nombre,pssw,mail,sex,d,country,CP,fecha_rev,tiempo_p);
                usuarios_free.add(n);
            }
            all_users.addAll(usuarios_free);

        }
        catch (SQLException e){

        }
    }

    default void crearNuevaPlaylist(int u_id,String titulo){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO playlist(titulo,fecha_creacion,usuario_id) VALUES ('"+titulo+"',CURDATE(),'"+u_id+"')");
            stm.executeUpdate("INSERT INTO activa(playlist_id) SELECT MAX(id) FROM playlist");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void tarjetas(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM tarjeta_credito");
            while(rs.next()){
                String tarjeta = rs.getString("numero_tarjeta");
                int mes_caducidad = rs.getInt("mes_caducidad");
                int año_caducidad = rs.getInt("anyo_caducidad");
                int cod_seguridad = rs.getInt("codigo_seguridad");
                int id_forma_pago = rs.getInt("forma_pago_id");
                Tarjeta t = new Tarjeta(id_forma_pago,tarjeta,mes_caducidad,año_caducidad,cod_seguridad);
                lista_tarjetas.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuariosPaypal(){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM paypal");
            while(rs.next()){
                String username = rs.getString("username_paypal");
                int id_forma_pago = rs.getInt("forma_pago_id");
                Paypal p = new Paypal(id_forma_pago,username);
                lista_paypal.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void insertarUsuarioaPremium(int u_id,int forma_pago_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM free WHERE usuario_id = "+u_id);
            stm.executeUpdate("INSERT INTO premium (fecha_renovación,usuario_id) VALUES (DATE_ADD(CURDATE(),INTERVAL 30 DAY),'"+u_id+"')");
            stm.executeUpdate("INSERT INTO suscripcion(fecha_inicio,fecha_fin,premium_usuario_id) VALUES (CURDATE(),DATE_ADD(CURDATE(),INTERVAL 30 DAY),'"+u_id+"')");
            stm.executeUpdate("INSERT INTO pago(fecha,total,forma_pago_id,suscripcion_id) SELECT CURDATE(),15.99,'"+forma_pago_id+"',MAX(s.id) FROM suscripcion s");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void registrarNuevoUsuario(String username, String password, String email, String sexo, LocalDate fecha_nac,String pais,String cp){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO usuario(username,password,email,genero,fecha_nacimiento,pais,codigo_postal) VALUES ('"+username+"','"+password+"','"+email+"','"+sexo+"','"+fecha_nac+"','"+pais+"','"+cp+"')");
            stm.executeUpdate("INSERT INTO free (fecha_revision,usuario_id) SELECT CURDATE(),MAX(u.id) FROM usuario u");
            stm.executeUpdate("INSERT INTO playlist (titulo,fecha_creacion,usuario_id) SELECT CONCAT('favorita_',(SELECT MAX(id) FROM usuario)),CURDATE(),MAX(id) FROM usuario");
            stm.executeUpdate("INSERT INTO favoritas (playlist_id) SELECT MAX(id) FROM playlist");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioSigueAlbum(int u_id,int album_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO sigue_album(usuario_id,album_id) VALUES ('"+u_id+"','"+album_id+"')");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioNoSigueAlbum(int u_id , int album_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM sigue_album WHERE usuario_id='"+u_id+"' AND album_id='"+album_id+"'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioSigueArtista(int u_id,int artista_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO sigue_artista(usuario_id,artista_id) VALUES ('"+u_id+"','"+artista_id+"')");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioNoSigueArtista(int u_id , int artista_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM sigue_artista WHERE usuario_id='"+u_id+"' AND artista_id='"+artista_id+"'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioSiguePodcast(int u_id,int podcast_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO podcast_usuario(usuario_id,podcast_id) VALUES ('"+u_id+"','"+podcast_id+"')");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioNoSiguePodcast(int u_id,int podcast_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM podcast_usuario WHERE usuario_id='"+u_id+"' AND podcast_id='"+podcast_id+"'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void anyadirCancionPlaylist(int playlist_id , int cancion_id , int usuario_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO anyade_cancion_playlist(playlist_id,cancion_id,usuario_id,fecha_anyadida) VALUES ('"+playlist_id+"','"+cancion_id+"','"+usuario_id+"',NOW())");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void eliminarCancionPlaylist(int playlist_id , int cancion_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM anyade_cancion_playlist WHERE playlist_id='"+playlist_id+"' AND cancion_id='"+cancion_id+"'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioSiguePlaylist(int u_id, int playlist_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO sigue_playlist(usuario_id,playlist_id) VALUES ('"+u_id+"','"+playlist_id+"')");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioNoSiguePlaylist(int u_id, int playlist_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM sigue_playlist WHERE usuario_id='"+u_id+"' AND playlist_id='"+playlist_id+"'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void sigueUsuario(int u_id){
        try {
            usuarios_seguidos.clear();
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM sigue_usuario WHERE usuario_id='"+u_id+"'");
            while(rs.next()){
                int id = rs.getInt("usuario_seguido_id");
                for (Usuario u : all_users){
                    if (u.getId() == id){
                        usuarios_seguidos.add(u);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioSigueUsuario(int u_id,int u_seguido_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO sigue_usuario(usuario_id,usuario_seguido_id) VALUES ('"+u_id+"','"+u_seguido_id+"')");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioNoSigueUsuario(int u_id, int u_seguido_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM sigue_usuario WHERE usuario_id='"+u_id+"' AND usuario_seguido_id='"+u_seguido_id+"'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioGuardaCancion(int u_id,int c_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("INSERT INTO guarda_cancion(usuario_id,cancion_id) VALUES ('"+u_id+"','"+c_id+"')");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    default void usuarioNoGuardaCancion(int u_id, int c_id){
        try {
            Connection connection = conexion();
            Statement stm = connection.createStatement();
            stm.executeUpdate("DELETE FROM guarda_cancion WHERE usuario_id='"+u_id+"' AND cancion_id='"+c_id+"'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
